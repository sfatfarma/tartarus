<?php

function tartarus_htaccess_editor()
{
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['htaccess_backup'])) 
    {
        $htaccess_default = $tartarus_Main_Settings['htaccess_backup'];
    }
    else
    {
        $htaccess_default = '';
    }
?>
<script>
function reset2() {
    document.getElementById("text2").value = `<?php echo $htaccess_default;?>`;
}
</script>
<div class="gs_popuptype_holder">
<table>
<tr>
<td>
<b>.HTACCESS</b>
<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
    <div class="bws_hidden_help_text" style="min-width: 260px;">
        <?php
    echo ".htaccess is a configuration file for use on web servers running the Apache Web Server software. When a .htaccess file is placed in a directory which is in turn 'loaded via the Apache Web Server', then the .htaccess file is detected and executed by the Apache Web Server software.. Change this only if you know what you are doing!";
?>
    </div>
</div>
<?php
    $file2 = ABSPATH . '.htaccess';
    
    if (isset($_POST['text2'])) {
        file_put_contents($file2, stripslashes($_POST['text2']));
    }
    if (file_exists($file2)) {
        $text2 = file_get_contents($file2);
    } else {
        $text2 = ".HTACCESS file does not exist! Create it from sitemap menu page!";
    }
?>
<form action="" method="post">
<textarea rows="30" cols="90" id="text2" name="text2"><?php
    echo stripslashes(htmlspecialchars($text2));
?></textarea><br/>
<input type="submit" />
<input type="button" value="Reset" onclick="javascript:reset2();" />
</form>
</td>
</tr>
</table>
</div>
<?php
}
?>