<?php
function tartarus_admin_settings()
{
?>
<div class="wrap gs_popuptype_holder seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php">
<?php
    settings_fields('tartarus_option_group');
    do_settings_sections('tartarus_option_group');
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['tartarus_enabled'])) {
        $tartarus_enabled = $tartarus_Main_Settings['tartarus_enabled'];
    } else {
        $tartarus_enabled = '';
    }
    if (isset($tartarus_Main_Settings['excepted_ips'])) {
        $excepted_ips = $tartarus_Main_Settings['excepted_ips'];
    } else {
        $excepted_ips = '';
    }
    if (isset($tartarus_Main_Settings['excepted_bots'])) {
        $excepted_bots = $tartarus_Main_Settings['excepted_bots'];
    } else {
        $excepted_bots = '';
    }
    if (isset($tartarus_Main_Settings['banned_text'])) {
        $banned_text = $tartarus_Main_Settings['banned_text'];
    } else {
        $banned_text = 'You are not allowed to view this resource!';
    }
    if (isset($tartarus_Main_Settings['send_email_address'])) {
        $send_email_address = $tartarus_Main_Settings['send_email_address'];
    } else {
        $send_email_address = get_option('admin_email');;
    }
    if (isset($tartarus_Main_Settings['send_email'])) {
        $send_email = $tartarus_Main_Settings['send_email'];
    } else {
        $send_email = '';
    }
    if (isset($tartarus_Main_Settings['user_agent_check'])) {
        $user_agent_check = $tartarus_Main_Settings['user_agent_check'];
    } else {
        $user_agent_check = '';
    }
    if (isset($tartarus_Main_Settings['redirect_badbot'])) {
        $redirect_badbot = $tartarus_Main_Settings['redirect_badbot'];
    } else {
        $redirect_badbot = '';
    }
    if (isset($tartarus_Main_Settings['redirect_referralSpam'])) {
        $redirect_referralSpam = $tartarus_Main_Settings['redirect_referralSpam'];
    } else {
        $redirect_referralSpam = '';
    }
    if (isset($tartarus_Main_Settings['redirect_goodbot'])) {
        $redirect_goodbot = $tartarus_Main_Settings['redirect_goodbot'];
    } else {
        $redirect_goodbot = '';
    }
    if (isset($tartarus_Main_Settings['add_robots'])) {
        $add_robots = $tartarus_Main_Settings['add_robots'];
    } else {
        $add_robots = '';
    }
    if (isset($tartarus_Main_Settings['log_visits'])) {
        $log_visits = $tartarus_Main_Settings['log_visits'];
    } else {
        $log_visits = 'Bot';
    }
    if (isset($tartarus_Main_Settings['exclude_own_traffic'])) {
        $exclude_own_traffic = $tartarus_Main_Settings['exclude_own_traffic'];
    } else {
        $exclude_own_traffic = '';
    }
    if (isset($tartarus_Main_Settings['honeypot_method'])) {
        $honeypot_method = $tartarus_Main_Settings['honeypot_method'];
    } else {
        $honeypot_method = '';
    }
    if (isset($tartarus_Main_Settings['enable_trap'])) {
        $enable_trap = $tartarus_Main_Settings['enable_trap'];
    } else {
        $enable_trap = '';
    }
    if (isset($tartarus_Main_Settings['honeypot_method_text'])) {
        $honeypot_method_text = $tartarus_Main_Settings['honeypot_method_text'];
    } else {
        $honeypot_method_text = '';
    }
    if (isset($tartarus_Main_Settings['honeypot_method_ban'])) {
        $honeypot_method_ban = $tartarus_Main_Settings['honeypot_method_ban'];
    } else {
        $honeypot_method_ban = '';
    }
    if (isset($tartarus_Main_Settings['allow_logged_in'])) {
        $allow_logged_in = $tartarus_Main_Settings['allow_logged_in'];
    } else {
        $allow_logged_in = '';
    }
    if (isset($tartarus_Main_Settings['allow_admin'])) {
        $allow_admin = $tartarus_Main_Settings['allow_admin'];
    } else {
        $allow_admin = '';
    }
    if (isset($tartarus_Main_Settings['add_nofollow'])) {
        $add_nofollow = $tartarus_Main_Settings['add_nofollow'];
    } else {
        $add_nofollow = '';
    }
    if (isset($tartarus_Main_Settings['redirect_referralSpam_url'])) {
        $redirect_referralSpam_url = $tartarus_Main_Settings['redirect_referralSpam_url'];
    } else {
        $redirect_referralSpam_url = '';
    }
    if (isset($tartarus_Main_Settings['redirect_goodbot_names'])) {
        $redirect_goodbot_names = $tartarus_Main_Settings['redirect_goodbot_names'];
    } else {
        $redirect_goodbot_names = '';
    }
    if (isset($tartarus_Main_Settings['redirect_badbot_names'])) {
        $redirect_badbot_names = $tartarus_Main_Settings['redirect_badbot_names'];
    } else {
        $redirect_badbot_names = '';
    }
    if (isset($tartarus_Main_Settings['htaccess_block'])) {
        $htaccess_block = $tartarus_Main_Settings['htaccess_block'];
    } else {
        $htaccess_block = '';
    }
?>
<script>
                var tartarus_admin_json = {
                    tartarus_enabled: '<?php
    echo $tartarus_enabled;
?>',
                    excepted_bots: '<?php
    echo $excepted_bots;
?>',
                    excepted_ips: '<?php
    echo $excepted_ips;
?>',
                    banned_text: '<?php
    echo $banned_text;
?>',
                    send_email: '<?php
    echo $send_email;
?>',
                    send_email_address: '<?php
    echo $send_email_address;
?>',
                    user_agent_check: '<?php
    echo $user_agent_check;
?>',
                    redirect_badbot: '<?php
    echo $redirect_badbot;
?>',
                    redirect_goodbot: '<?php
    echo $redirect_goodbot;
?>',
                    redirect_referralSpam: '<?php
    echo $redirect_referralSpam;
?>',
                    add_robots: '<?php
    echo $add_robots;
?>',
                    exclude_own_traffic: '<?php
    echo $exclude_own_traffic;
?>',
                    log_visits: '<?php
    echo $log_visits;
?>',
                    honeypot_method: '<?php
    echo $honeypot_method;
?>',
                    enable_trap: '<?php
    echo $enable_trap;
?>',
                    honeypot_method_text: '<?php
    echo $honeypot_method_text;
?>',
                    honeypot_method_ban: '<?php
    echo $honeypot_method_ban;
?>',
                    allow_logged_in: '<?php
    echo $allow_logged_in;
?>',
                    allow_admin: '<?php
    echo $allow_admin;
?>',
                    add_nofollow: '<?php
    echo $add_nofollow;
?>',
                    redirect_referralSpam_url: '<?php
    echo $redirect_referralSpam_url;
?>',
                    redirect_badbot_names: '<?php
    echo $redirect_badbot_names;
?>',
                    redirect_goodbot_names: '<?php
    echo $redirect_goodbot_names;
?>',
                    htaccess_block: '<?php
    echo $htaccess_block;
?>'

}
</script>
<script type="text/javascript">
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))
        {            
            jQuery(".hideMain").show();
        }
        else
        {
            jQuery(".hideMain").hide();
        }
        if(jQuery('#send_email').is(":checked"))
        {            
            jQuery(".hideMail").show();
        }
        else
        {
            jQuery(".hideMail").hide();
        }
        if(jQuery('#honeypot_method').is(":checked"))
        {            
            jQuery(".comHide").show();
        }
        else
        {
            jQuery(".comHide").hide();
        }
        if(jQuery('#enable_trap').is(":checked"))
        {            
            jQuery(".hideBot").show();
        }
        else
        {
            jQuery(".hideBot").hide();
        }
        if(jQuery('#redirect_goodbot').is(":checked"))
        {            
            jQuery(".hideGood").show();
        }
        else
        {
            jQuery(".hideGood").hide();
        }
        if(jQuery('#redirect_badbot').is(":checked"))
        {            
            jQuery(".hideBad").show();
        }
        else
        {
            jQuery(".hideBad").hide();
        }
        if(jQuery('#redirect_referralSpam').is(":checked"))
        {            
            jQuery(".hideRef").show();
        }
        else
        {
            jQuery(".hideRef").hide();
        }
        if(jQuery("#log_visits option:selected").text().trim() === 'Disable') 
        {            
            jQuery(".logHide").hide();
        }
        else
        {
            jQuery(".logHide").show();
        }
    }
    window.onload = mainChanged;
</script>
<div ng-app="tarsettingsApp" ng-controller="tarsettingsController" ng-cloak ng-init="initialized()">
<div class="tartarus_class">
<table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Tartarus Crawl Control Plugin Main Switch:</b>&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Tartarus Crawl Control Plugin. This acts like a main switch.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="tartarus_enabled" name="tartarus_Main_Settings[tartarus_enabled]" onChange="mainChanged()" <?php
    if ($tartarus_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="tartarus_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
        <h2>Bot Trap Feature:</h2>
                    <table><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to activate the bot trap feature of this plugin? This feature will add an invisible link (but bots can still see it) to your website. Anyone who follows that link, will be banned from your website.";
?>
                        </div>
                    </div>
                    <b>Enable 'Bot Trap Feature':</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_trap" name="tartarus_Main_Settings[enable_trap]" onChange="mainChanged()" <?php
    if ($enable_trap == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideBot">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This feature will add an entry to your robots.txt file that tells the crawling spiders not to follow the tartarus trap link. If they will understand and follow this directive, they will not be caught in the bot trap. However, you may chose not to include this directive in your robots.txt file, and to catch and ban every robot that crawls your website.";
?>
                        </div>
                    </div>
                    <b>Include Trap Link Exclusion to robots.txt:</b>
                    </div>
                    </td><td>
                    <div class="hideBot">
                    <input type="checkbox" id="add_robots" name="tartarus_Main_Settings[add_robots]"<?php
    if ($add_robots == 'on')
        echo ' checked ';
?>>
        </div>          
        </td></tr><tr><td>
        <div class="hideBot">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This feature will add 'NOFOLLOW' directive to the link of the bot trap. It is highly recommended that you enable this feature (and also the 'Include Trap Link Exclusion to robots.txt' feature), to not ban innocent bots (that follow the robots.txt rules).";
?>
                        </div>
                    </div>
                    <b>Add 'Nofollow' to Trap Link:</b>
                    </div>
                    </td><td>
                    <div class="hideBot">
                    <input type="checkbox" id="add_nofollow" name="tartarus_Main_Settings[add_nofollow]"<?php
    if ($add_nofollow == 'on')
        echo ' checked ';
?>>
        </div>          
        </td></tr><tr><td>
        <hr/></td><td><hr/></tr><tr><td><h2>Automatically Ban Bots:</h2>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This feature detects and bans the major crawling bots (Google, Bing, Yahoo, etc.). Note that if you enable this, the SEO score of your website will be seriously affected! Use this only if your website suffers from massive slowdown from massive crawling. For a full list of blocked and allowed bots and spiders, please consult the plugin documentation.";
?>
                        </div>
                    </div>
                    <b>'Good Bot' Blocker:</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_goodbot" name="tartarus_Main_Settings[redirect_goodbot]" onChange="mainChanged()"<?php
    if ($redirect_goodbot == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideGood">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Add bot names that you consider are good bots. Notice that these bots will be automatically banned on access. You can check the initial good bot names in the plugin documentation. Add names separated by a comma.";
?>
                        </div>
                    </div>
                    <b>Extra 'Good Bot' Names to Ban:</b>
                    </div>
                    </td><td>
                    <div class="hideGood">
                    <input type="text" name="tartarus_Main_Settings[redirect_goodbot_names]" ng-model="settings.redirect_goodbot_names">
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This feature blocks a large number of bots that are known to be aggresive, except the major ones that will benefit your website SEO (Google, Bing, Yahoo). For a full list of blocked and allowed bots and spiders, please consult the plugin documentation. This feature can improve your website's performance.";
?>
                        </div>
                    </div>
                    <b>'Bad Bot' Blocker:</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_badbot" name="tartarus_Main_Settings[redirect_badbot]" onChange="mainChanged()"<?php
    if ($redirect_badbot == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideBad">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Add bot names that you consider are bad bots. Note that they will be automatically banned on access. You can check the initial bad bot names in the plugin documentation. Add names separated by a comma.";
?>
                        </div>
                    </div>
                    <b>Extra 'Bad Bot' Names:</b>
                    </div>
                    </td><td>
                    <div class="hideBad">
                    <input type="text" name="tartarus_Main_Settings[redirect_badbot_names]" ng-model="settings.redirect_badbot_names">
                    </div>
        </td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td><h2><a href="admin.php?page=tartarus_page_access_list">Log Visits on Website Feature</a>:</h2></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This feature will log visits on your website. You can choose to log only bots, only humans or both.";
?>
                        </div>
                    </div>
                    <b>Enable Website Visits Logging:</b>
                    
                    </td><td>
                    <select id="log_visits" name="tartarus_Main_Settings[log_visits]" style="width:140px;max-width:180px;">
                                  <option value="All"<?php
    if ($log_visits == "All") {
        echo " selected";
    }
?>>All Visits</option>
                                  <option value="Bot"<?php
    if ($log_visits == "Bot") {
        echo " selected";
    }
?>>Bot Only</option>
                                  <option value="Human"<?php
    if ($log_visits == "Human") {
        echo " selected";
    }
?>>Human Only</option>
                                  <option value="None"<?php
    if ($log_visits == "None") {
        echo " selected";
    }
?>>Disable</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div class="logHide">
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to exclude the traffic comming from your own IP Adress? This feature is useful to get more precise results.";
?>
                        </div>
                    </div>
                    <b>Exclude Own Traffic:</b>
                    </div>
                    </td><td>
                    <div class="logHide">
                    <input type="checkbox" id="exclude_own_traffic" name="tartarus_Main_Settings[exclude_own_traffic]"<?php
    if ($exclude_own_traffic == 'on')
        echo ' checked ';
?>>
        </div>             
        </div>
        </td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td><h2><a href="admin.php?page=tartarus_blocked_bots_list">Bot Banning Settings</a>:</h2></td></tr>
        <tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The names of the bots who will be permitted to crawl your site in any conditions. Some known bot type are excepted by default. Note that if you want to define more bot names, you should enter them all here, separated by comma. Also note that wildcard expressions or regexp are also supported.";
?>
                        </div>
                    </div>
                    <b>Excepted Bot Names:</b>
                    </td><td>
                    <input type="text" name="tartarus_Main_Settings[excepted_bots]" ng-model="settings.excepted_bots">
        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The IP Adresses of the bots that will be permitted to crawl your site in any conditions. Note that if you want to define more bot IP Adresses, you should enter them all here, separated by comma. Also note that wildcard expressions or regexp are also supported.";
?>
                        </div>
                    </div>
                    <b>Excepted Bot IP Adresses:</b>
                    </td><td>
                    <input type="text" name="tartarus_Main_Settings[excepted_ips]" ng-model="settings.excepted_ips">
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you what to receive an e-mail every time a new bot gets banned from your website?";
?>
                        </div>
                    </div>
                    <b>Send E-mail When a New Bot Gets Banned:</b>
                    </div>
                    </td><td>
                    <input type="checkbox" id="send_email" name="tartarus_Main_Settings[send_email]" onclick="mainChanged()" <?php
    if ($send_email == 'on')
        echo ' checked ';
?>>
        </td></tr><tr><td>
        <div class='hideMail'>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The e-mail address where the e-mail should be sent. Note that this plugin will automatically detect and warn you, if e-mail sending does not function on your WordPress installation.";
?>
                        </div>
                    </div>
                    <b>Your E-mail Adress:</b> 
<?php $mailResult = false;
$mailResult = wp_mail( 'you@example.com', 'How are you', 'Hurray' );
echo $mailResult ? '<div class="tooltip">Mail sending OK!
  <span class="tooltiptext">Automatic test e-mail was sent! Mail sending is working!</span>
</div>' : '<div class="tooltip">Issue detected!
  <span class="tooltiptext">Automatic test email cannot be sent! Please verify your WordPress e-mailing feature configuration!</span>
</div>';?>
                    
                    </td><td>
                    <div class='hideMail'>
                    <input type="email" name="tartarus_Main_Settings[send_email_address]" ng-model="settings.send_email_address">
        </div></div>
        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown to the banned bots. You can customize this text for human visitors who are curious and follow this link.";
?>
                        </div>
                    </div>
                    <b>Custom 'You are Banned Page' Text:</b>
                    </td><td>
                    <input type="text" name="tartarus_Main_Settings[banned_text]" ng-model="settings.banned_text">
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to check both IP Adress and User Agent of visiting bots? If you uncheck this, ban will be given only for the IP Adress of the visitor. If you check this, ban will be given for the IP Adress - User-Agent combination. So, if this is checked, the user or the bot can change it's user agent (or browser), and the ban will not apply.";
?>
                        </div>
                    </div>
                    <b>Beside the Crawler's IP, also Check it's User Agent:</b>
                    </td><td>
                    <input type="checkbox" id="user_agent_check" name="tartarus_Main_Settings[user_agent_check]" <?php
    if ($user_agent_check == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Allow access to site for logged in users even if they are banned. (Warning! Users will be banned as soon as they log out!)";
?>
                        </div>
                    </div>
                    <b>Always Allow Acces for Logged In Users:</b>
                    </td><td>
                    <input type="checkbox" id="allow_logged_in" name="tartarus_Main_Settings[allow_logged_in]" <?php
    if ($allow_logged_in == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Allow access to login and admin pages even if user is banned. Warning! If you deny access for yourself to login and admin pages, you risk locking yourself out of WordPress! Use this settings with caution!";
?>
                        </div>
                    </div>
                    <b>Always Allow Acces to 'Login' and 'Admin' pages:</b>
                    </td><td>
                    <input type="checkbox" id="allow_admin" name="tartarus_Main_Settings[allow_admin]" <?php
    if ($allow_admin == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr>
        <tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <h2>Other Features:</h2></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This feature blocks all spam comming from refferal sites that are known to spam. A full list of these site, can be found in the plugin documentation.";
?>
                        </div>
                    </div>
                    <b>'Referral Spam' Blocker:</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_referralSpam" name="tartarus_Main_Settings[redirect_referralSpam]" onChange="mainChanged()"<?php
    if ($redirect_referralSpam == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideRef">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Add URLs that you consider are referral spam sources. You can check the initial referral spam sources in the plugin documentation. Add sources separated by a comma.";
?>
                        </div>
                    </div>
                    <b>Referral Spam Extra URLs:</b>
                    </div>
                    </td><td>
                    <div class="hideRef">
                    <input type="text" name="tartarus_Main_Settings[redirect_referralSpam_url]" ng-model="settings.redirect_referralSpam_url">
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This feature blocks all spam comming from commenting spam bots. It uses a honeypot method to achieve this.";
?>
                        </div>
                    </div>
                    <b>'Bot Comment Spam' Blocker:</b>
                    
                    </td><td>
                    <input type="checkbox" id="honeypot_method" name="tartarus_Main_Settings[honeypot_method]" onChange="mainChanged()"<?php
    if ($honeypot_method == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="comHide">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown to the spamming bots.";
?>
                        </div>
                    </div>
                    <b>'Bot Comment Spam' Blocker Text to be Shown:</b>
                    </div>
                    </td><td>
                    <div class="comHide">
                    <input type="text" name="tartarus_Main_Settings[honeypot_method_text]" ng-model="settings.honeypot_method_text">
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="comHide">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you also want to ban IP Adresses that try to spam in your comment section? If you uncheck this, spam will only be blocked, but bot's IP adresses will not be banned.";
?>
                        </div>
                    </div>
                    <b>'Bot Comment Spam' Also Ban Bot IP:</b>
                    </div>
                    </td><td>
                    <div class="comHide">
                    <input type="checkbox" id="honeypot_method_ban" name="tartarus_Main_Settings[honeypot_method_ban]"<?php
    if ($honeypot_method_ban == 'on')
        echo ' checked ';
?>>
        </div>            
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you also want to block some of the known bad bots, by using your .htaccess file? List of blocked bots can be found in the plugin documentation.";
?>
                        </div>
                    </div>
                    <b>Block Known 'Bad Bots' with the .htaccess File:</b>
                    </td><td>
                    <input type="checkbox" id="htaccess_block" name="tartarus_Main_Settings[htaccess_block]"<?php
    if ($htaccess_block == 'on')
        echo ' checked ';
?>>          
        </div>
        </td></tr></table>
        </div>
        </div>
        
<div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save Settings"/></p></div>
    </form>
</div>
</div>
<?php
}
?>