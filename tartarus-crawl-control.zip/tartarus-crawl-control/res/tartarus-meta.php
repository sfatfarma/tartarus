<?php
function tartarus_meta()
{
?><div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('tartarus_option_group4');
    do_settings_sections('tartarus_option_group4');
    $tartarus_Meta_Settings = get_option('tartarus_Meta_Settings', false);
    if (isset($tartarus_Meta_Settings['seo_noindex_posts'])) {
        $seo_noindex_posts = $tartarus_Meta_Settings['seo_noindex_posts'];
    } else {
        $seo_noindex_posts = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_pages'])) {
        $seo_noindex_pages = $tartarus_Meta_Settings['seo_noindex_pages'];
    } else {
        $seo_noindex_pages = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_media'])) {
        $seo_noindex_media = $tartarus_Meta_Settings['seo_noindex_media'];
    } else {
        $seo_noindex_media = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_category'])) {
        $seo_noindex_category = $tartarus_Meta_Settings['seo_noindex_category'];
    } else {
        $seo_noindex_category = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_archive'])) {
        $seo_noindex_archive = $tartarus_Meta_Settings['seo_noindex_archive'];
    } else {
        $seo_noindex_archive = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_search'])) {
        $seo_noindex_search = $tartarus_Meta_Settings['seo_noindex_search'];
    } else {
        $seo_noindex_search = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_tax'])) {
        $seo_noindex_tax = $tartarus_Meta_Settings['seo_noindex_tax'];
    } else {
        $seo_noindex_tax = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_nf'])) {
        $seo_noindex_nf = $tartarus_Meta_Settings['seo_noindex_nf'];
    } else {
        $seo_noindex_nf = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_home'])) {
        $seo_noindex_home = $tartarus_Meta_Settings['seo_noindex_home'];
    } else {
        $seo_noindex_home = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_tag'])) {
        $seo_noindex_tag = $tartarus_Meta_Settings['seo_noindex_tag'];
    } else {
        $seo_noindex_tag = '';
    }
    
    if (isset($tartarus_Meta_Settings['seo_nofollow_category'])) {
        $seo_nofollow_category = $tartarus_Meta_Settings['seo_nofollow_category'];
    } else {
        $seo_nofollow_category = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_archive'])) {
        $seo_nofollow_archive = $tartarus_Meta_Settings['seo_nofollow_archive'];
    } else {
        $seo_nofollow_archive = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_search'])) {
        $seo_nofollow_search = $tartarus_Meta_Settings['seo_nofollow_search'];
    } else {
        $seo_nofollow_search = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_tax'])) {
        $seo_nofollow_tax = $tartarus_Meta_Settings['seo_nofollow_tax'];
    } else {
        $seo_nofollow_tax = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_nf'])) {
        $seo_nofollow_nf = $tartarus_Meta_Settings['seo_nofollow_nf'];
    } else {
        $seo_nofollow_nf = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_home'])) {
        $seo_nofollow_home = $tartarus_Meta_Settings['seo_nofollow_home'];
    } else {
        $seo_nofollow_home = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_tag'])) {
        $seo_nofollow_tag = $tartarus_Meta_Settings['seo_nofollow_tag'];
    } else {
        $seo_nofollow_tag = '';
    }
    
    if (isset($tartarus_Meta_Settings['seo_noodp_category'])) {
        $seo_noodp_category = $tartarus_Meta_Settings['seo_noodp_category'];
    } else {
        $seo_noodp_category = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_archive'])) {
        $seo_noodp_archive = $tartarus_Meta_Settings['seo_noodp_archive'];
    } else {
        $seo_noodp_archive = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_search'])) {
        $seo_noodp_search = $tartarus_Meta_Settings['seo_noodp_search'];
    } else {
        $seo_noodp_search = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_tax'])) {
        $seo_noodp_tax = $tartarus_Meta_Settings['seo_noodp_tax'];
    } else {
        $seo_noodp_tax = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_nf'])) {
        $seo_noodp_nf = $tartarus_Meta_Settings['seo_noodp_nf'];
    } else {
        $seo_noodp_nf = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_home'])) {
        $seo_noodp_home = $tartarus_Meta_Settings['seo_noodp_home'];
    } else {
        $seo_noodp_home = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_tag'])) {
        $seo_noodp_tag = $tartarus_Meta_Settings['seo_noodp_tag'];
    } else {
        $seo_noodp_tag = '';
    }
    
    if (isset($tartarus_Meta_Settings['seo_noydir_category'])) {
        $seo_noydir_category = $tartarus_Meta_Settings['seo_noydir_category'];
    } else {
        $seo_noydir_category = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_archive'])) {
        $seo_noydir_archive = $tartarus_Meta_Settings['seo_noydir_archive'];
    } else {
        $seo_noydir_archive = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_search'])) {
        $seo_noydir_search = $tartarus_Meta_Settings['seo_noydir_search'];
    } else {
        $seo_noydir_search = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_tax'])) {
        $seo_noydir_tax = $tartarus_Meta_Settings['seo_noydir_tax'];
    } else {
        $seo_noydir_tax = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_nf'])) {
        $seo_noydir_nf = $tartarus_Meta_Settings['seo_noydir_nf'];
    } else {
        $seo_noydir_nf = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_home'])) {
        $seo_noydir_home = $tartarus_Meta_Settings['seo_noydir_home'];
    } else {
        $seo_noydir_home = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_tag'])) {
        $seo_noydir_tag = $tartarus_Meta_Settings['seo_noydir_tag'];
    } else {
        $seo_noydir_tag = '';
    }
    
    if (isset($tartarus_Meta_Settings['seo_nofollow_posts'])) {
        $seo_nofollow_posts = $tartarus_Meta_Settings['seo_nofollow_posts'];
    } else {
        $seo_nofollow_posts = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_pages'])) {
        $seo_nofollow_pages = $tartarus_Meta_Settings['seo_nofollow_pages'];
    } else {
        $seo_nofollow_pages = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_media'])) {
        $seo_nofollow_media = $tartarus_Meta_Settings['seo_nofollow_media'];
    } else {
        $seo_nofollow_media = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_posts'])) {
        $seo_noodp_posts = $tartarus_Meta_Settings['seo_noodp_posts'];
    } else {
        $seo_noodp_posts = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_pages'])) {
        $seo_noodp_pages = $tartarus_Meta_Settings['seo_noodp_pages'];
    } else {
        $seo_noodp_pages = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_media'])) {
        $seo_noodp_media = $tartarus_Meta_Settings['seo_noodp_media'];
    } else {
        $seo_noodp_media = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_posts'])) {
        $seo_noydir_posts = $tartarus_Meta_Settings['seo_noydir_posts'];
    } else {
        $seo_noydir_posts = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_pages'])) {
        $seo_noydir_pages = $tartarus_Meta_Settings['seo_noydir_pages'];
    } else {
        $seo_noydir_pages = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_media'])) {
        $seo_noydir_media = $tartarus_Meta_Settings['seo_noydir_media'];
    } else {
        $seo_noydir_media = '';
    }
    if (isset($tartarus_Meta_Settings['seo_misc'])) {
        $seo_misc = $tartarus_Meta_Settings['seo_misc'];
    } else {
        $seo_misc = '';
    }
?>
<script>
                var tartarus_admin_json = {}
</script>
            
    <script type="text/javascript">
    window.onload = miscChanged;
    function miscChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))   
            jQuery(".hideTot").show();
        else
            jQuery(".hideTot").hide();
    }
</script>
            <div ng-app="tarsettingsApp" ng-controller="tarsettingsController" ng-cloak ng-init="initialized()">
                <div>
                    <div class="gs_popuptype_holder">
                    <table>
                    <tr>
                    <td>
                        <span class="gs-sub-heading"><b>Meta Tags Settings:</b></span>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable meta tags to tell bots your indexing preference? For more info about this feature, check plugin documentation.";
?>
                                        </div>
                                    </div>
                                    </td>
                                    <td>
                        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="seo_misc" name="tartarus_Meta_Settings[seo_misc]" onchange="miscChanged()" <?php
    if ($seo_misc == 'on')
        echo ' checked ';
?>>
                                            <label for="seo_misc"></label>
                                    </div>
                                    </td>
                                    </tr>
                    </table>
                    <div class="hideTot">
                    <hr/>
                    <table class="tabel" width="90%">
                    <tr>
                    <td>
                    </td>
                    <td>
                    
                    <b>Posts</b>
                    </td>
                    <td>
                    <b>Pages
                    </td>
                    <td>
                    <b>Category</b>
                    </td>
                    <td>
                    <b>Archive</b>
                    </td>
                    <td>
                    <b>Search</b>
                    </td>
                    <td>
                    <b>Taxonomy</b>
                    </td>
                    <td>
                    <b>Not Found</b>
                    </td>
                    <td>
                    <b>Home</b>
                    </td>
                    <td>
                    <b>Tag</b>
                    </td>
                    <td>
                    <b>Media</b>
                    </td>
                    </tr>
                    <tr>
                    <td>
                    <span class="gs-sub-heading"><b>NOINDEX:</b></span>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "NOINDEX is a meta tag that can be displayed to search robots, that requests them not to index content.  The specific directive differs between each search robot.  The default behaviour is 'Do not show this page in search results and do not show a �Cached� link in search results'.<br/><a href='https://support.google.com/webmasters/answer/93710?hl=en' target='_blank'>Official link</a>";
?>
                        </div>
                    </div>
                    </td>
                    <td>
                        <input type="checkbox" class="checkboxOne" id="seo_noindex_posts" name="tartarus_Meta_Settings[seo_noindex_posts]"<?php
    if ($seo_noindex_posts == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td>
                        <input type="checkbox" class="checkboxOne" id="seo_noindex_pages" name="tartarus_Meta_Settings[seo_noindex_pages]"<?php
    if ($seo_noindex_pages == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td>                    
                        <input type="checkbox" class="checkboxOne" id="seo_noindex_category" name="tartarus_Meta_Settings[seo_noindex_category]"<?php
    if ($seo_noindex_category == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noindex_archive" name="tartarus_Meta_Settings[seo_noindex_archive]"<?php
    if ($seo_noindex_archive == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noindex_search" name="tartarus_Meta_Settings[seo_noindex_search]"<?php
    if ($seo_noindex_search == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noindex_tax" name="tartarus_Meta_Settings[seo_noindex_tax]"<?php
    if ($seo_noindex_tax == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noindex_nf" name="tartarus_Meta_Settings[seo_noindex_nf]"<?php
    if ($seo_noindex_nf == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noindex_home" name="tartarus_Meta_Settings[seo_noindex_home]"<?php
    if ($seo_noindex_home == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noindex_tag" name="tartarus_Meta_Settings[seo_noindex_tag]"<?php
    if ($seo_noindex_tag == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noindex_media" name="tartarus_Meta_Settings[seo_noindex_media]"<?php
    if ($seo_noindex_media == 'on')
        echo ' checked ';
?>>
                    </td>
                    </tr>
                    <tr>
                    <td>
                    <span class="gs-sub-heading"><b>NOFOLLOW:</b></span>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "NOFOLLOW is a meta tag that can be displayed to search robots that requests them not to follow any links in the content.  This can be especially useful when either you do not want search engines to follow links to certain content on your site, or more importantly when you do not want search engines to follow outbound links to other people�s websites.<br/><a href='https://support.google.com/webmasters/answer/96569?hl=en' target='_blank'>Official link</a>";
?>
                        </div>
                    </div>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_nofollow_posts" name="tartarus_Meta_Settings[seo_nofollow_posts]"<?php
    if ($seo_nofollow_posts == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_nofollow_pages" name="tartarus_Meta_Settings[seo_nofollow_pages]"<?php
    if ($seo_nofollow_pages == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_nofollow_category" name="tartarus_Meta_Settings[seo_nofollow_category]"<?php
    if ($seo_nofollow_category == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_nofollow_archive" name="tartarus_Meta_Settings[seo_nofollow_archive]"<?php
    if ($seo_nofollow_archive == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_nofollow_search" name="tartarus_Meta_Settings[seo_nofollow_search]"<?php
    if ($seo_nofollow_search == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_nofollow_tax" name="tartarus_Meta_Settings[seo_nofollow_tax]"<?php
    if ($seo_nofollow_tax == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_nofollow_nf" name="tartarus_Meta_Settings[seo_nofollow_nf]"<?php
    if ($seo_nofollow_nf == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_nofollow_home" name="tartarus_Meta_Settings[seo_nofollow_home]"<?php
    if ($seo_nofollow_home == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_nofollow_tag" name="tartarus_Meta_Settings[seo_nofollow_tag]"<?php
    if ($seo_nofollow_tag == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_nofollow_media" name="tartarus_Meta_Settings[seo_nofollow_media]"<?php
    if ($seo_nofollow_media == 'on')
        echo ' checked ';
?>>
                    </td>
                    </tr> 
                    <tr>
                    <td>
                    <span class="gs-sub-heading"><b>NOODP:</b></span>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "NOODP is a meta tag that tells search engines such as Google not to use the Open Directory Project as a source for generating titles and descriptions in search results.";
?>
                        </div>
                    </div>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noodp_posts" name="tartarus_Meta_Settings[seo_noodp_posts]"<?php
    if ($seo_noodp_posts == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noodp_pages" name="tartarus_Meta_Settings[seo_noodp_pages]"<?php
    if ($seo_noodp_pages == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noodp_category" name="tartarus_Meta_Settings[seo_noodp_category]"<?php
    if ($seo_noodp_category == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noodp_archive" name="tartarus_Meta_Settings[seo_noodp_archive]"<?php
    if ($seo_noodp_archive == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noodp_search" name="tartarus_Meta_Settings[seo_noodp_search]"<?php
    if ($seo_noodp_search == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noodp_tax" name="tartarus_Meta_Settings[seo_noodp_tax]"<?php
    if ($seo_noodp_tax == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noodp_nf" name="tartarus_Meta_Settings[seo_noodp_nf]"<?php
    if ($seo_noodp_nf == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noodp_home" name="tartarus_Meta_Settings[seo_noodp_home]"<?php
    if ($seo_noodp_home == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noodp_tag" name="tartarus_Meta_Settings[seo_noodp_tag]"<?php
    if ($seo_noodp_tag == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noodp_media" name="tartarus_Meta_Settings[seo_noodp_media]"<?php
    if ($seo_noodp_media == 'on')
        echo ' checked ';
?>>
                    </td>
                    </tr> 
                    <tr>
                    <td>
                    <span class="gs-sub-heading"><b>NOYDIR:</b></span>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "NOYDIR is a meta tag that tells search engines such as Google not to use the Yahoo! Directory as a source for generating titles and descriptions in search results.";
?>
                        </div>
                    </div>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noydir_posts" name="tartarus_Meta_Settings[seo_noydir_posts]"<?php
    if ($seo_noydir_posts == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noydir_pages" name="tartarus_Meta_Settings[seo_noydir_pages]"<?php
    if ($seo_noydir_pages == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td>
                        <input type="checkbox" class="checkboxOne" id="seo_noydir_category" name="tartarus_Meta_Settings[seo_noydir_category]"<?php
    if ($seo_noydir_category == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noydir_archive" name="tartarus_Meta_Settings[seo_noydir_archive]"<?php
    if ($seo_noydir_archive == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noydir_search" name="tartarus_Meta_Settings[seo_noydir_search]"<?php
    if ($seo_noydir_search == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noydir_tax" name="tartarus_Meta_Settings[seo_noydir_tax]"<?php
    if ($seo_noydir_tax == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noydir_nf" name="tartarus_Meta_Settings[seo_noydir_nf]"<?php
    if ($seo_noydir_nf == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noydir_home" name="tartarus_Meta_Settings[seo_noydir_home]"<?php
    if ($seo_noydir_home == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td> 
                        <input type="checkbox" class="checkboxOne" id="seo_noydir_tag" name="tartarus_Meta_Settings[seo_noydir_tag]"<?php
    if ($seo_noydir_tag == 'on')
        echo ' checked ';
?>>
                    </td>
                    <td>     
                        <input type="checkbox" class="checkboxOne" id="seo_noydir_media" name="tartarus_Meta_Settings[seo_noydir_media]"<?php
    if ($seo_noydir_media == 'on')
        echo ' checked ';
?>>
                    </td>
                    </tr>
                    </table>
                    </div>
                    </div>
                    </div>  
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
</div>
</div><?php
}
?>