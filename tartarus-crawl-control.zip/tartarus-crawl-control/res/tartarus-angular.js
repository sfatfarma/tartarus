angular.module('tarsettingsApp', ['ngSanitize'])
.controller('tarsettingsController', function($scope) {
    $scope.settings = tartarus_admin_json;
});