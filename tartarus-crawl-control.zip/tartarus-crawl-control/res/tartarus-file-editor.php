<?php

function tartarus_file_editor()
{
?>
<script>
function reset2() {
    document.getElementById("text3").value = `User-Agent: *
Allow: /wp-content/uploads/
Disallow: /wp-content/plugins/
Disallow: /readme.html
`;
}
</script>
<div class="gs_popuptype_holder">
<table>
<tr>
<td>
<b>ROBOTS.TXT</b>
<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
    <div class="bws_hidden_help_text" style="min-width: 260px;">
        <?php
    echo "Web site owners use the /robots.txt file to give instructions about their site to web robots; this is called The Robots Exclusion Protocol. Change this only if you know what you are doing!";
?>
    </div>
</div>
<?php
    $file3 = ABSPATH . 'robots.txt';
    if (isset($_POST['text3'])) {
        file_put_contents($file3, $_POST['text3']);
    }
    if (file_exists($file3)) {
        $text3 = file_get_contents($file3);
    } else {
        $text2 = "Robots.txt file does not exist!";
    }
?>
<form action="" method="post">
<textarea rows="30" cols="90" id="text3" name="text3"><?php
    echo stripslashes(htmlspecialchars($text3));
?></textarea><br/>
<input type="submit" />
<input type="button" value="Reset" onclick="javascript:reset2();" />
</form>
</td>
</tr>
</table>
</div>
<?php
}
?>