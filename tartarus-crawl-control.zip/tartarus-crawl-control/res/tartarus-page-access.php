<?php
function tartarus_page_access_list()
{
    $href_bot   = esc_url(add_query_arg(array(
        'list' => 'bot'
    ), admin_url('admin.php?page=tartarus_page_access_list')));
    $href_human = esc_url(add_query_arg(array(
        'list' => 'human'
    ), admin_url('admin.php?page=tartarus_page_access_list')));
    $href_all   = esc_url(admin_url('admin.php?page=tartarus_page_access_list'));
    $total_nr   = 0;
?>
	<div class="wrap gs_popuptype_holder">
		<h1 class="seo_pops">The list of page visits:</h1><a href="<?php
    echo $href_bot;
?>">List only Bots</a>&nbsp;&nbsp;<a href="<?php
    echo $href_human;
?>">List only Humans</a>&nbsp;&nbsp;<a href="<?php
    echo $href_all;
?>">List All</a>&nbsp;&nbsp;<a href="#" onclick="add_entry2()">Clear All Data</a>
        <hr/>
<?php
    echo '<div>';
    echo '<table id="tabela" class="tabela"><thead><tr><th style="cursor: pointer;" id="sl">User Agent</th><th style="cursor: pointer;" id="nm">Access Count</th><th style="cursor: pointer;" id="tp">Type</th></tr></thead>';
    
    $list = '';
    if (isset($_GET['list'])) {
        $list = $_GET['list'];
    }
    
    $dir     = plugin_dir_path(__FILE__);
    $ua_file = $dir . '../logs';
    if (file_exists($ua_file)) {
        if ($handle = opendir($ua_file)) {
            
            while (false !== ($entry = readdir($handle))) {
                
                if ($entry != "." && $entry != "..") {
                    $contents = file_get_contents($ua_file . "/" . $entry);
                    $str      = explode(",", $contents);
                    $cnt      = $str[0];
                    $type     = $str[1];
                    if ($list != '') {
                        if ($list == 'bot') {
                            if ($type == 'Bot' || $type == 'AlexaBot' || $type == 'TwitterBot' || $type == 'FacebookBot' || $type == 'YandexBot' || $type == 'BaiduBot' || $type == 'BingBot' || $type == 'GoogleBot' || $type == 'YahooBot') {
                                echo "<tr><td>" . $entry . "</td><td>" . $cnt . "</td><td>" . $type . "</td></tr>";
                                $total_nr += $cnt;
                            }
                        } else {
                            if ($type != 'Bot' && $type != 'AlexaBot' && $type != 'TwitterBot' && $type != 'FacebookBot' && $type != 'YandexBot' && $type != 'BaiduBot' && $type != 'BingBot' && $type != 'GoogleBot' && $type != 'YahooBot') {
                                echo "<tr><td>" . $entry . "</td><td>" . $cnt . "</td><td>" . $type . "</td></tr>";
                                $total_nr += $cnt;
                            }
                        }
                    } else {
                        echo "<tr><td>" . $entry . "</td><td>" . $cnt . "</td><td>" . $type . "</td></tr>";
                        $total_nr += $cnt;
                    }
                }
            }
            closedir($handle);
        }
    }
    echo '</table>';
    echo 'Total listed page access: ' . $total_nr;
    echo '</div>';
    echo "<script>
function sortTable(f,n){
    var rows = jQuery('#tabela tbody  tr').get();
    rows.sort(function(a, b) {
        var A = getVal(a);
        var B = getVal(b);
        if(A < B) {
            return -1*f;
        }
        if(A > B) {
            return 1*f;
        }
        return 0;
    });
    function getVal(elm){
        var v = jQuery(elm).children('td').eq(n).text().toUpperCase();
        if(jQuery.isNumeric(v)){
            v = parseInt(v,10);
        }
        return v;
    }
    jQuery.each(rows, function(index, row) {
        jQuery('#tabela').children('tbody').append(row);
    });
}
var f_sl = 1; // flag to toggle the sorting order
var f_nm = 1; // flag to toggle the sorting order
jQuery('#sl').click(function(){
    f_sl *= -1; // toggle the sorting order
    var n = jQuery(this).prevAll().length;
    sortTable(f_sl,n);
});
jQuery('#nm').click(function(){
    f_nm *= -1; // toggle the sorting order
    var n = jQuery(this).prevAll().length;
    sortTable(f_nm,n);
});
jQuery('#tp').click(function(){
    f_nm *= -1; // toggle the sorting order
    var n = jQuery(this).prevAll().length;
    sortTable(f_nm,n);
});
</script>";
?>
<script type="text/javascript" >
function add_entry2()
{
    var data = {
        action: 'tartarus_my_action2'
    };
    jQuery.post(ajaxurl, data, function(response) {
        location.reload();
    });
}
</script>
<?php
}
?>