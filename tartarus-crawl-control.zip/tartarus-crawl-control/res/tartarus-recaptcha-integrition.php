<?php
function tartarus_recaptcha_integrition()
{
?>
	<div class="wrap gs_popuptype_holder">
    <form id="myForm" method="post" action="options.php">
<?php
    settings_fields('tartarus_option_group3');
    do_settings_sections('tartarus_option_group3');
    $tartarus_ReCaptcha_Settings = get_option('tartarus_ReCaptcha_Settings', false);
    if (isset($tartarus_ReCaptcha_Settings['recaptcha_enabled'])) {
        $recaptcha_enabled = $tartarus_ReCaptcha_Settings['recaptcha_enabled'];
    } else {
        $recaptcha_enabled = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['site_key'])) {
        $site_key = $tartarus_ReCaptcha_Settings['site_key'];
    } else {
        $site_key = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['secret_key'])) {
        $secret_key = $tartarus_ReCaptcha_Settings['secret_key'];
    } else {
        $secret_key = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['recaptcha_login'])) {
        $recaptcha_login = $tartarus_ReCaptcha_Settings['recaptcha_login'];
    } else {
        $recaptcha_login = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['recaptcha_signup'])) {
        $recaptcha_signup = $tartarus_ReCaptcha_Settings['recaptcha_signup'];
    } else {
        $recaptcha_signup = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['recaptcha_comment'])) {
        $recaptcha_comment = $tartarus_ReCaptcha_Settings['recaptcha_comment'];
    } else {
        $recaptcha_comment = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['recaptcha_disable_logged_in'])) {
        $recaptcha_disable_logged_in = $tartarus_ReCaptcha_Settings['recaptcha_disable_logged_in'];
    } else {
        $recaptcha_disable_logged_in = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['recaptcha_lostpassword'])) {
        $recaptcha_lostpassword = $tartarus_ReCaptcha_Settings['recaptcha_lostpassword'];
    } else {
        $recaptcha_lostpassword = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['lost_password_spam'])) {
        $lost_password_spam = $tartarus_ReCaptcha_Settings['lost_password_spam'];
    } else {
        $lost_password_spam = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['lost_password_incorrect'])) {
        $lost_password_incorrect = $tartarus_ReCaptcha_Settings['lost_password_incorrect'];
    } else {
        $lost_password_incorrect = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['sign_up_incorrect'])) {
        $sign_up_incorrect = $tartarus_ReCaptcha_Settings['sign_up_incorrect'];
    } else {
        $sign_up_incorrect = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['sign_up_spam'])) {
        $sign_up_spam = $tartarus_ReCaptcha_Settings['sign_up_spam'];
    } else {
        $sign_up_spam = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['log_in_incorrect'])) {
        $log_in_incorrect = $tartarus_ReCaptcha_Settings['log_in_incorrect'];
    } else {
        $log_in_incorrect = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['log_in_spam'])) {
        $log_in_spam = $tartarus_ReCaptcha_Settings['log_in_spam'];
    } else {
        $log_in_spam = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['comment_incorrect'])) {
        $comment_incorrect = $tartarus_ReCaptcha_Settings['comment_incorrect'];
    } else {
        $comment_incorrect = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['comment_spam'])) {
        $comment_spam = $tartarus_ReCaptcha_Settings['comment_spam'];
    } else {
        $comment_spam = '';
    }
    if (isset($tartarus_ReCaptcha_Settings['recaptcha_theme'])) {
        $recaptcha_theme = $tartarus_ReCaptcha_Settings['recaptcha_theme'];
    } else {
        $recaptcha_theme = 'Light';
    }
    if (isset($tartarus_ReCaptcha_Settings['recaptcha_language'])) {
        $recaptcha_language = $tartarus_ReCaptcha_Settings['recaptcha_language'];
    } else {
        $recaptcha_language = 'en';
    }
?>
<script>
                var tartarus_admin_json = {
                    recaptcha_enabled: '<?php
    echo $recaptcha_enabled;
?>',
                    site_key: '<?php
    echo $site_key;
?>',
                    secret_key: '<?php
    echo $secret_key;
?>',
                    recaptcha_comment: '<?php
    echo $recaptcha_comment;
?>',
                    recaptcha_lostpassword: '<?php
    echo $recaptcha_lostpassword;
?>',
                    recaptcha_signup: '<?php
    echo $recaptcha_signup;
?>',
                    recaptcha_login: '<?php
    echo $recaptcha_login;
?>',
                    recaptcha_disable_logged_in: '<?php
    echo $recaptcha_disable_logged_in;
?>',
                    lost_password_spam: '<?php
    echo $lost_password_spam;
?>',
                    lost_password_incorrect: '<?php
    echo $lost_password_incorrect;
?>',
                    sign_up_incorrect: '<?php
    echo $sign_up_incorrect;
?>',
                    sign_up_spam: '<?php
    echo $sign_up_spam;
?>',
                    log_in_incorrect: '<?php
    echo $log_in_incorrect;
?>',
                    log_in_spam: '<?php
    echo $log_in_spam;
?>',
                    comment_incorrect: '<?php
    echo $comment_incorrect;
?>',
                    recaptcha_theme: '<?php
    echo $recaptcha_theme;
?>',
                    comment_spam: '<?php
    echo $comment_spam;
?>',
                    recaptcha_language: '<?php
    echo $recaptcha_language;
?>'
}
</script>
<script type="text/javascript">
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))
        {            
            jQuery(".hideMain").show();
        }
        else
        {
            jQuery(".hideMain").hide();
        }
        if(jQuery('#recaptcha_signup').is(":checked"))
        {            
            jQuery(".hideSignup").show();
        }
        else
        {
            jQuery(".hideSignup").hide();
        }
        if(jQuery('#recaptcha_login').is(":checked"))
        {            
            jQuery(".hideLogin").show();
        }
        else
        {
            jQuery(".hideLogin").hide();
        }
        if(jQuery('#recaptcha_comment').is(":checked"))
        {            
            jQuery(".hideComment").show();
        }
        else
        {
            jQuery(".hideComment").hide();
        }
        if(jQuery('#recaptcha_lostpassword').is(":checked"))
        {            
            jQuery(".hideLostPassword").show();
        }
        else
        {
            jQuery(".hideLostPassword").hide();
        }
    }
    window.onload = mainChanged;
</script>
<div ng-app="tarsettingsApp" ng-controller="tarsettingsController" ng-cloak ng-init="initialized()">
<div class="tartarus_class">
<table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Enable ReCaptch Feature:</b>&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable ReCaptcha feature of this plugin.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="recaptcha_enabled" name="tartarus_ReCaptcha_Settings[recaptcha_enabled]" onChange="mainChanged()" <?php
    if ($recaptcha_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="recaptcha_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
    <table><tr><td>
    <h2>Site Key and Secret Key:</h2></td></tr><tr><td>
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please <a href='https://www.google.com/recaptcha/admin#list' target='_blank'>register your blog through the Google reCAPTCHA admin page</a> and enter the site key in the fields below. <a href='https://developers.google.com/recaptcha/intro' target='_blank'>More help.</a>";
?>
                        </div>
                    </div>
                    <b>Site Key:</b>
                    </td><td>
                    <input type="text" name="tartarus_ReCaptcha_Settings[site_key]" ng-model="settings.site_key" pattern='^6[0-9a-zA-Z_-]*' required>
                    </td></tr><tr><td>
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please <a href='https://www.google.com/recaptcha/admin#list' target='_blank'>register your blog through the Google reCAPTCHA admin page</a> and enter the secret key in the fields below. <a href='https://developers.google.com/recaptcha/intro' target='_blank'>More help.</a>";
?>
                        </div>
                    </div>
                    <b>Secret Key:</b>
                    </td><td>
                    <input type="text" name="tartarus_ReCaptcha_Settings[secret_key]" ng-model="settings.secret_key" pattern='^6[0-9a-zA-Z_-]*' required>
                    </td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td><h2>General ReCaptcha Settings:</h2></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show ReCaptcha in the sign-up form?";
?>
                        </div>
                    </div>
                    <b>Sign-up Form Integrition:</b>
                    
                    </td><td>
                    <input type="checkbox" id="recaptcha_signup" name="tartarus_ReCaptcha_Settings[recaptcha_signup]" onChange="mainChanged()" <?php
    if ($recaptcha_signup == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideSignup">
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please enter the message that will be shown to the user when he must reenter the captcha in the sing up form, because it was incorrect.";
?>
                        </div>
                    </div>
                    <b>Sign-up Form Incorrect Captcha Message:</b>
                    </div>
                    </td><td>
                    <div class="hideSignup">
                    <input type="text" name="tartarus_ReCaptcha_Settings[sign_up_incorrect]" ng-model="settings.sign_up_incorrect">
                    </div>
                    </td></tr><tr><td>
                    <div class="hideSignup">
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please enter the message that will be shown to the user when he tries to spam in the sing-up form.";
?>
                        </div>
                    </div>
                    <b>Sign-up Form Spam Captcha Message:</b>
                    </div>
                    </td><td>
                    <div class="hideSignup">
                    <input type="text" name="tartarus_ReCaptcha_Settings[sign_up_spam]" ng-model="settings.sign_up_spam">
                    </div>
                    </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you what to show ReCaptcha in the login form?";
?>
                        </div>
                    </div>
                    <b>Login Form Integrition:</b>
                    
                    </td><td>
                    <input type="checkbox" id="recaptcha_login" name="tartarus_ReCaptcha_Settings[recaptcha_login]" onChange="mainChanged()" <?php
    if ($recaptcha_login == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideLogin">
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please enter the message that will be shown to the user when he must reenter the captcha in the login form, because it was incorrect.";
?>
                        </div>
                    </div>
                    <b>Login Form Incorrect Captcha Message:</b>
                    </div>
                    </td><td>
                    <div class="hideLogin">
                    <input type="text" name="tartarus_ReCaptcha_Settings[log_in_incorrect]" ng-model="settings.log_in_incorrect">
                    </div>
                    </td></tr><tr><td>
                    <div class="hideLogin">
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please enter the message that will be shown to the user when he tries to spam in the log in form.";
?>
                        </div>
                    </div>
                    <b>Login Form Spam Captcha Message:</b>
                    </div>
                    </td><td>
                    <div class="hideLogin">
                    <input type="text" name="tartarus_ReCaptcha_Settings[log_in_spam]" ng-model="settings.log_in_spam">
                    </div>
                    </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you what to show ReCaptcha in the comment form?";
?>
                        </div>
                    </div>
                    <b>Comment Form Integrition:</b>
                    
                    </td><td>
                    <input type="checkbox" id="recaptcha_comment" name="tartarus_ReCaptcha_Settings[recaptcha_comment]" onChange="mainChanged()" <?php
    if ($recaptcha_comment == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideComment">
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please enter the message that will be shown to the user when he must reenter the captcha in the comment form, because it was incorrect.";
?>
                        </div>
                    </div>
                    <b>Comment Form Incorrect Captcha Message:</b>
                    </div>
                    </td><td>
                    <div class="hideComment">
                    <input type="text" name="tartarus_ReCaptcha_Settings[comment_incorrect]" ng-model="settings.comment_incorrect">
                    </div>
                    </td></tr><tr><td>
                    <div class="hideComment">
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please enter the message that will be shown to the user when he tries to spam in the comment form.";
?>
                        </div>
                    </div>
                    <b>Comment Form Spam Captcha Message:</b>
                    </div>
                    </td><td>
                    <div class="hideComment">
                    <input type="text" name="tartarus_ReCaptcha_Settings[comment_spam]" ng-model="settings.comment_spam">
                    </div>
                    </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you what to show ReCaptcha in the lost password form?";
?>
                        </div>
                    </div>
                    <b>Lost Password Form Integrition:</b>
                    
                    </td><td>
                    <input type="checkbox" id="recaptcha_lostpassword" name="tartarus_ReCaptcha_Settings[recaptcha_lostpassword]" onChange="mainChanged()" <?php
    if ($recaptcha_lostpassword == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideLostPassword">
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please enter the message that will be shown to the user when he must reenter the captcha in the lost password form, because it was incorrect.";
?>
                        </div>
                    </div>
                    <b>Lost Password Form Incorrect Captcha Message:</b>
                    </div>
                    </td><td>
                    <div class="hideLostPassword">
                    <input type="text" name="tartarus_ReCaptcha_Settings[lost_password_incorrect]" ng-model="settings.lost_password_incorrect">
                    </div>
                    </td></tr><tr><td>
                    <div class="hideLostPassword">
    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please enter the message that will be shown to the user when he tries to spam in the lost password form.";
?>
                        </div>
                    </div>
                    <b>Lost Password Form Spam Captcha Message:</b>
                    </div>
                    </td><td>
                    <div class="hideLostPassword">
                    <input type="text" name="tartarus_ReCaptcha_Settings[lost_password_spam]" ng-model="settings.lost_password_spam">
                    </div>
                    </td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td><h2>Recaptcha Design Settings:</h2></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the theme you would like to apply to the recaptchas. You can select between light or dark.";
?>
                        </div>
                    </div>
                    <b>ReCaptcha Theme:</b>
                    
                    </td><td>
                    <select id="recaptcha_theme" name="tartarus_ReCaptcha_Settings[recaptcha_theme]" style="width:140px;max-width:180px;">
                                  <option value="Light"<?php
    if ($recaptcha_theme == "Light") {
        echo " selected";
    }
?>>Light</option>
                                  <option value="Dark"<?php
    if ($recaptcha_theme == "Dark") {
        echo " selected";
    }
?>>Dark</option>
                    </select>  
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the language you would like to apply to the recaptchas.";
?>
                        </div>
                    </div>
                    <b>ReCaptcha Language:</b>
                    
                    </td><td>
                    <select id="recaptcha_language" name="tartarus_ReCaptcha_Settings[recaptcha_language]" style="width:140px;max-width:180px;">
                                  <option value="ar"<?php
    if ($recaptcha_language == "ar") {
        echo " selected";
    }
?>>Arabic</option>
                                  <option value="bg"<?php
    if ($recaptcha_language == "bg") {
        echo " selected";
    }
?>>Bulgarian</option>
                                  <option value="ca"<?php
    if ($recaptcha_language == "ca") {
        echo " selected";
    }
?>>Catalan</option>
                                  <option value="zh-CN"<?php
    if ($recaptcha_language == "zh-CN") {
        echo " selected";
    }
?>>Chinese (Simplified)</option>
                                  <option value="zh-TW"<?php
    if ($recaptcha_language == "zh-TW") {
        echo " selected";
    }
?>>Chinese (Traditional)</option>
                                  <option value="hr"<?php
    if ($recaptcha_language == "hr") {
        echo " selected";
    }
?>>Croatian</option>
                                  <option value="cs"<?php
    if ($recaptcha_language == "ar") {
        echo " selected";
    }
?>>Czech</option>
                                  <option value="da"<?php
    if ($recaptcha_language == "da") {
        echo " selected";
    }
?>>Danish</option>
                                  <option value="nl"<?php
    if ($recaptcha_language == "nl") {
        echo " selected";
    }
?>>Dutch</option>
                                  <option value="en-GB"<?php
    if ($recaptcha_language == "en-GB") {
        echo " selected";
    }
?>>English (UK)</option>
                                  <option value="en"<?php
    if ($recaptcha_language == "en") {
        echo " selected";
    }
?>>English (US)</option>
                                  <option value="fil"<?php
    if ($recaptcha_language == "fil") {
        echo " selected";
    }
?>>Filipino</option>
                                  <option value="fi"<?php
    if ($recaptcha_language == "fi") {
        echo " selected";
    }
?>>Finnish</option>
                                  <option value="fr"<?php
    if ($recaptcha_language == "fr") {
        echo " selected";
    }
?>>French</option>
                                  <option value="fr-CA"<?php
    if ($recaptcha_language == "fr-CA") {
        echo " selected";
    }
?>>French (Canadian)</option>
                                  <option value="de"<?php
    if ($recaptcha_language == "de") {
        echo " selected";
    }
?>>German</option>
                                  <option value="de-AT"<?php
    if ($recaptcha_language == "de-AT") {
        echo " selected";
    }
?>>German (Austria)</option>
                                  <option value="de-CH"<?php
    if ($recaptcha_language == "de-CH") {
        echo " selected";
    }
?>>German (Switzerland)</option>
                                  <option value="el"<?php
    if ($recaptcha_language == "el") {
        echo " selected";
    }
?>>Greek</option>
                                  <option value="iw"<?php
    if ($recaptcha_language == "iw") {
        echo " selected";
    }
?>>Hebrew</option>
                                  <option value="hi"<?php
    if ($recaptcha_language == "hi") {
        echo " selected";
    }
?>>Hindi</option>
                                  <option value="hu"<?php
    if ($recaptcha_language == "hu") {
        echo " selected";
    }
?>>Hungarain</option>
                                  <option value="id"<?php
    if ($recaptcha_language == "id") {
        echo " selected";
    }
?>>Indonesian</option>
                                  <option value="it"<?php
    if ($recaptcha_language == "it") {
        echo " selected";
    }
?>>Italian</option>
                                  <option value="ja"<?php
    if ($recaptcha_language == "ja") {
        echo " selected";
    }
?>>Japanese</option>
                                  <option value="ko"<?php
    if ($recaptcha_language == "ko") {
        echo " selected";
    }
?>>Korean</option>
                                  <option value="lv"<?php
    if ($recaptcha_language == "lv") {
        echo " selected";
    }
?>>Latvian</option>
                                  <option value="lt"<?php
    if ($recaptcha_language == "lt") {
        echo " selected";
    }
?>>Lithuanian</option>
                                  <option value="no"<?php
    if ($recaptcha_language == "no") {
        echo " selected";
    }
?>>Norwegian</option>
                                  <option value="fa"<?php
    if ($recaptcha_language == "fa") {
        echo " selected";
    }
?>>Persian</option>
                                  <option value="pl"<?php
    if ($recaptcha_language == "pl") {
        echo " selected";
    }
?>>Polish</option>
                                  <option value="pt"<?php
    if ($recaptcha_language == "pt") {
        echo " selected";
    }
?>>Portuguese</option>
                                  <option value="pt-BR"<?php
    if ($recaptcha_language == "pt-BR") {
        echo " selected";
    }
?>>Portuguese (Brazil)</option>
                                  <option value="pt-PT"<?php
    if ($recaptcha_language == "pt-PT") {
        echo " selected";
    }
?>>Portuguese (Portugal)</option>
                                  <option value="ro"<?php
    if ($recaptcha_language == "ro") {
        echo " selected";
    }
?>>Romanian</option>
                                  <option value="ru"<?php
    if ($recaptcha_language == "ru") {
        echo " selected";
    }
?>>Russian</option>
                                  <option value="sr"<?php
    if ($recaptcha_language == "sr") {
        echo " selected";
    }
?>>Serbian</option>
                                  <option value="sk"<?php
    if ($recaptcha_language == "sk") {
        echo " selected";
    }
?>>Slovak</option>
                                  <option value="sl"<?php
    if ($recaptcha_language == "sl") {
        echo " selected";
    }
?>>Slovenian</option>
                                  <option value="es"<?php
    if ($recaptcha_language == "es") {
        echo " selected";
    }
?>>Spanish</option>
                                  <option value="es-419"<?php
    if ($recaptcha_language == "es-419") {
        echo " selected";
    }
?>>Spanish (Latin America)</option>
                                  <option value="sv"<?php
    if ($recaptcha_language == "sv") {
        echo " selected";
    }
?>>Swedish</option>
                                  <option value="th"<?php
    if ($recaptcha_language == "th") {
        echo " selected";
    }
?>>Thai</option>
                                  <option value="tr"<?php
    if ($recaptcha_language == "tr") {
        echo " selected";
    }
?>>Turkish</option>
                                  <option value="uk"<?php
    if ($recaptcha_language == "uk") {
        echo " selected";
    }
?>>Ukrainian</option>
                                  <option value="vi"<?php
    if ($recaptcha_language == "vi") {
        echo " selected";
    }
?>>Vietnamese</option>
                    </select>  
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you what to not show recaptchas for logged in users?";
?>
                        </div>
                    </div>
                    <b>Disable Recaptcha if User is Logged In:</b>
                    
                    </td><td>
                    <input type="checkbox" id="recaptcha_disable_logged_in" name="tartarus_ReCaptcha_Settings[recaptcha_disable_logged_in]" <?php
    if ($recaptcha_disable_logged_in == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr>     
                    </table>
                    <div>
                    <h2>ReCaptcha Preview:</h2>
                    <p>Do not enable ReCaptchas if the Recaptcha Preview does not appear or does not function correctly!</p>
<?php
                    $tartarus_ReCaptcha_Settings = get_option('tartarus_ReCaptcha_Settings', false);
    $key                         = $tartarus_ReCaptcha_Settings['site_key'];
    $theme                       = $tartarus_ReCaptcha_Settings['recaptcha_theme'];
    echo '<div class="g-recaptcha" data-sitekey="' . $key . '" data-theme="' . $theme . '" style="transform:scale(0.90);-webkit-transform:scale(0.90);transform-origin:0 0;-webkit-transform-origin:0 0;"></div>';
?>
    </div>
                    </div></div>
                    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save Settings"/></p></div>
                    </form>
	</div>
<?php
}
?>