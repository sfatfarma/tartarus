<?php
function tartarus_blocked_bots_list()
{
?>
	<div class="wrap gs_popuptype_holder">
<?php
    $href_referral    = esc_url(add_query_arg(array(
        'list' => 'referral'
    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
    $href_comment_bot = esc_url(add_query_arg(array(
        'list' => 'comment'
    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
    $href_trapped_bot = esc_url(add_query_arg(array(
        'list' => 'trapped'
    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
    $href_bad_bot     = esc_url(add_query_arg(array(
        'list' => 'bad'
    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
    $href_good_bot    = esc_url(add_query_arg(array(
        'list' => 'good'
    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
    $href_all         = esc_url(admin_url('admin.php?page=tartarus_blocked_bots_list'));
    $list             = '';
    if (isset($_GET['list'])) {
        $list = $_GET['list'];
    }
    $href_del_all = esc_url(add_query_arg(array(
        'del' => 'all'
    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
?>
        <b>Add a manual rule:</b><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Here you can add a manual rule that will apply on your website. Note that you can block access of specific IPs or specific User Agents (browsers or bots). Also note that you can use regular expressions here. For more information, check the plugin's documentation file.";
?>
                        </div>
                    </div><br/>
        <form method="post" id="myForm" action="admin.php?page=tartarus_blocked_bots_list">New IP Address:&nbsp;&nbsp;<input type="text" name="new_IP" id="new_IP" required pattern="((^|\.)((25[0-5])|(2[0-4]\d)|(1\d\d)|([1-9]?\d))){4}$"/>&nbsp;&nbsp;New User Agent:&nbsp;<input type="text" required name="new_UA" id="new_UA"/>&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Add Rule"/></form>
		<h1 class="seo_pops">The list of bad bots:</h1>&nbsp;<a href="<?php
    echo $href_referral;
?>">List only Referral Spam Bans</a>&nbsp;&nbsp;<a href="<?php
    echo $href_comment_bot;
?>">List CommentBot Bans</a>&nbsp;&nbsp;<a href="<?php
    echo $href_trapped_bot;
?>">List TrappedBot Bans</a>&nbsp;&nbsp;<a href="<?php
    echo $href_bad_bot;
?>">List BadBot Bans</a>&nbsp;&nbsp;<a href="<?php
    echo $href_good_bot;
?>">List GoodBot Bans</a>&nbsp;&nbsp;<a href="<?php
    echo $href_all;
?>">List All</a>&nbsp;&nbsp;<a href="<?php
    echo $href_del_all;
?>" title="Delete all bots">Clear this list</a>
        <hr/>
<?php
    $tartarus_crawl_list = get_option('tartarus_crawl_list');
    echo '<div>';
    echo '<table class="tabela">';
    if (isset($tartarus_crawl_list) && $tartarus_crawl_list != '' && !empty($tartarus_crawl_list)) {
        echo '<thead><tr><th>Delete</th><th style="cursor: pointer;" id="sl">Date</th><th style="cursor: pointer;" id="nm">IP Address</th><th style="cursor: pointer;" id="tp">User Agent</th><th style="cursor: pointer;" id="br">Ban Reason</th><th>More Info</th></tr></thead>';
        if ($list == 'referral') {
            foreach ($tartarus_crawl_list as $key => $val) {
                list($ip_address, $request_uri, $query_string, $user_agent, $referrer, $protocol, $method, $date, $reason) = $val;
                if ($reason == 'ReferralSpam') {
                    $href  = esc_url(add_query_arg(array(
                        'del' => $key
                    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                    $href2 = esc_url(add_query_arg(array(
                        'expand' => $key
                    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                    $data  = '<td><strong>' . $date . '</strong></td><td>' . $ip_address . '</td><td>' . $user_agent . '</td><td>' . $reason . '</td><td><a href="' . $href2 . '" title="More Info">More Info</a></td></tr>';
                    echo '<tr><td><a href="' . $href . '" title="Delete this bot">X</a></td>' . $data;
                }
            }
        } elseif ($list == 'comment') {
            foreach ($tartarus_crawl_list as $key => $val) {
                list($ip_address, $request_uri, $query_string, $user_agent, $referrer, $protocol, $method, $date, $reason) = $val;
                if ($reason == 'CommentSpam') {
                    $href  = esc_url(add_query_arg(array(
                        'del' => $key
                    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                    $href2 = esc_url(add_query_arg(array(
                        'expand' => $key
                    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                    $data  = '<td><strong>' . $date . '</strong></td><td>' . $ip_address . '</td><td>' . $user_agent . '</td><td>' . $reason . '</td><td><a href="' . $href2 . '" title="More Info">More Info</a></td></tr>';
                    echo '<tr><td><a href="' . $href . '" title="Delete this bot">X</a></td>' . $data;
                }
            }
        } elseif ($list == 'trapped') {
            foreach ($tartarus_crawl_list as $key => $val) {
                list($ip_address, $request_uri, $query_string, $user_agent, $referrer, $protocol, $method, $date, $reason) = $val;
                if ($reason == 'TrappedBot') {
                    $href  = esc_url(add_query_arg(array(
                        'del' => $key
                    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                    $href2 = esc_url(add_query_arg(array(
                        'expand' => $key
                    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                    $data  = '<td><strong>' . $date . '</strong></td><td>' . $ip_address . '</td><td>' . $user_agent . '</td><td>' . $reason . '</td><td><a href="' . $href2 . '" title="More Info">More Info</a></td></tr>';
                    echo '<tr><td><a href="' . $href . '" title="Delete this bot">X</a></td>' . $data;
                }
            }
        } elseif ($list == 'good') {
            foreach ($tartarus_crawl_list as $key => $val) {
                list($ip_address, $request_uri, $query_string, $user_agent, $referrer, $protocol, $method, $date, $reason) = $val;
                if ($reason == 'GoodBotBan') {
                    $href  = esc_url(add_query_arg(array(
                        'del' => $key
                    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                    $href2 = esc_url(add_query_arg(array(
                        'expand' => $key
                    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                    $data  = '<td><strong>' . $date . '</strong></td><td>' . $ip_address . '</td><td>' . $user_agent . '</td><td>' . $reason . '</td><td><a href="' . $href2 . '" title="More Info">More Info</a></td></tr>';
                    echo '<tr><td><a href="' . $href . '" title="Delete this bot">X</a></td>' . $data;
                }
            }
        } elseif ($list == 'bad') {
            foreach ($tartarus_crawl_list as $key => $val) {
                list($ip_address, $request_uri, $query_string, $user_agent, $referrer, $protocol, $method, $date, $reason) = $val;
                if ($reason == 'BadBotBan') {
                    $href  = esc_url(add_query_arg(array(
                        'del' => $key
                    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                    $href2 = esc_url(add_query_arg(array(
                        'expand' => $key
                    ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                    $data  = '<td><strong>' . $date . '</strong></td><td>' . $ip_address . '</td><td>' . $user_agent . '</td><td>' . $reason . '</td><td><a href="' . $href2 . '" title="More Info">More Info</a></td></tr>';
                    echo '<tr><td><a href="' . $href . '" title="Delete this bot">X</a></td>' . $data;
                }
            }
        } else {
            foreach ($tartarus_crawl_list as $key => $val) {
                list($ip_address, $request_uri, $query_string, $user_agent, $referrer, $protocol, $method, $date, $reason) = $val;
                $href  = esc_url(add_query_arg(array(
                    'del' => $key
                ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                $href2 = esc_url(add_query_arg(array(
                    'expand' => $key
                ), admin_url('admin.php?page=tartarus_blocked_bots_list')));
                $data  = '<td><strong>' . $date . '</strong></td><td>' . $ip_address . '</td><td>' . $user_agent . '</td><td>' . $reason . '</td><td><a href="' . $href2 . '" title="More Info">More Info</a></td></tr>';
                echo '<tr><td><a href="' . $href . '" title="Delete this bot">X</a></td>' . $data;
            }
        }
    } else {
        echo "<tr><td><strong>No bots in the list.</strong></td></tr>";
    }
    echo '</table>';
    echo '</div>';
    echo "<script>
function sortTable(f,n){
    var rows = jQuery('#tabela tbody  tr').get();
    rows.sort(function(a, b) {
        var A = getVal(a);
        var B = getVal(b);
        if(A < B) {
            return -1*f;
        }
        if(A > B) {
            return 1*f;
        }
        return 0;
    });
    function getVal(elm){
        var v = jQuery(elm).children('td').eq(n).text().toUpperCase();
        if(jQuery.isNumeric(v)){
            v = parseInt(v,10);
        }
        return v;
    }
    jQuery.each(rows, function(index, row) {
        jQuery('#tabela').children('tbody').append(row);
    });
}
var f_sl = 1; // flag to toggle the sorting order
var f_nm = 1; // flag to toggle the sorting order
jQuery('#sl').click(function(){
    f_sl *= -1; // toggle the sorting order
    var n = jQuery(this).prevAll().length;
    sortTable(f_sl,n);
});
jQuery('#nm').click(function(){
    f_nm *= -1; // toggle the sorting order
    var n = jQuery(this).prevAll().length;
    sortTable(f_nm,n);
});
jQuery('#tp').click(function(){
    f_nm *= -1; // toggle the sorting order
    var n = jQuery(this).prevAll().length;
    sortTable(f_nm,n);
});
jQuery('#br').click(function(){
    f_nm *= -1; // toggle the sorting order
    var n = jQuery(this).prevAll().length;
    sortTable(f_nm,n);
});
</script>";
?>
</div>
<script type="text/javascript" >
    jQuery('#myForm').submit(function () {
    add_entry();
    return false;
});
function add_entry()
{
    if(jQuery("#myForm")[0].checkValidity()) {
        var data = {
            action: 'tartarus_my_action',
            new_UA: document.getElementById('new_UA').value,
            new_IP: document.getElementById('new_IP').value
        };
        jQuery.post(ajaxurl, data, function(response) {
            location.reload();
        });
    }
}
</script>
<?php
}
?>