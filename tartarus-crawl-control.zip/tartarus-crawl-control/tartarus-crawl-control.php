<?php
/** 
Plugin Name: Tartarus Crawl Control Plugin for WordPress
Plugin URI: http://codecanyon.net/user/kisded/portfolio
Description: This plugin puts you in full control of the crawling of your website by spiders and bots.
Author: kisded
Version: 1.1
Author URI: https://codecanyon.net/user/kisded
*/

require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/tartarus/master/info.json", __FILE__, "tartarus-crawl-control");
add_action('admin_menu', 'tartarus_register_my_custom_menu_page');
function tartarus_register_my_custom_menu_page()
{
    add_menu_page('Tartarus Crawl Control', 'Tartarus Crawl Control', 'manage_options', 'tartarus_admin_settings', 'tartarus_admin_settings', plugins_url('images/icon.png', __FILE__));
    add_submenu_page('tartarus_admin_settings', 'Main Settings', 'Main Settings', 'manage_options', 'tartarus_admin_settings');
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['tartarus_enabled']) && $tartarus_Main_Settings['tartarus_enabled'] === 'on') {
        add_submenu_page('tartarus_admin_settings', 'Blocked Bots List', 'Blocked Bots List', 'manage_options', 'tartarus_blocked_bots_list', 'tartarus_blocked_bots_list');
        add_submenu_page('tartarus_admin_settings', 'ReCaptcha Integrition', 'ReCaptcha Integrition', 'manage_options', 'tartarus_recaptcha_integrition', 'tartarus_recaptcha_integrition');
        add_submenu_page('tartarus_admin_settings', 'Page Access List', 'Page Access List', 'manage_options', 'tartarus_page_access_list', 'tartarus_page_access_list');
        add_submenu_page('tartarus_admin_settings', 'Robots.txt Editor', 'Robots.txt Editor', 'manage_options', 'tartarus_file_editor', 'tartarus_file_editor');
        add_submenu_page('tartarus_admin_settings', 'Htaccess Editor', 'Htaccess Editor', 'manage_options', 'tartarus_htaccess_editor', 'tartarus_htaccess_editor');
        add_submenu_page('tartarus_admin_settings', 'Meta Tags Editor', 'Meta Tags Editor', 'manage_options', 'tartarus_meta', 'tartarus_meta');
    }
}
$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'tartarus_add_settings_link');
function tartarus_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=tartarus_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}

function tartarus_add_ajaxurl()
{
    
    echo '<script type="text/javascript">
            var ajaxurl = "' . admin_url('admin-ajax.php') . '";
        </script>';
}
add_action('wp_head', 'tartarus_add_ajaxurl');

function tartarus_debug_to_console($data)
{
    
    if (is_array($data))
        $output = "<script>console.log( 'Debug Objects: " . implode(',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";
    
    echo $output;
}
register_activation_hook(__FILE__, 'tartarus_activation_callback');
function tartarus_activation_callback()
{
    $file2 = ABSPATH . '.htaccess';
    $file1 = ABSPATH . 'robots.txt';
    if (file_exists($file1)) {
        $text1 = file_get_contents($file1);
    } else {
        $text1 = "";
    }
    if (file_exists($file2)) {
        $text2 = file_get_contents($file2);
    } else {
        $text2 = "";
    }
    $tartarus_Main_Settings = array(
        'tartarus_enabled' => 'on',
        'excepted_ips' => '',
        'excepted_bots' => 'googlebot,bingbot,mediapartners-google,ia_archiver,msnbot,yandexbot,baiduspider,wordpress',
        'banned_text' => 'You are not allowed to view this resource!',
        'send_email_address' => '',
        'send_email' => '',
        'user_agent_check' => '',
        'redirect_badbot' => '',
        'redirect_referralSpam' => '',
        'redirect_goodbot' => '',
        'add_robots' => 'on',
        'log_visits' => 'Bot',
        'exclude_own_traffic' => 'on',
        'honeypot_method' => '',
        'enable_trap' => 'on',
        'honeypot_method_text' => 'No Spam Please!',
        'honeypot_method_ban' => '',
        'allow_logged_in' => 'on',
        'allow_admin' => 'on',
        'add_nofollow' => 'on',
        'redirect_referralSpam_url' => '',
        'redirect_badbot_names' => '',
        'redirect_goodbot_names' => '',
        'htaccess_block' => '',
        'htaccess_backup' => $text2,
        'robots_backup' => $text1
    );
    if (!get_option('tartarus_Main_Settings')) {
        add_option('tartarus_Main_Settings', $tartarus_Main_Settings);
    } /*else {
        delete_option('tartarus_Main_Settings');
        add_option('tartarus_Main_Settings', $tartarus_Main_Settings);
    }*/
    if (!get_option('tartarus_crawl_list')) {
        add_option('tartarus_crawl_list', array());
    }/* else {
        delete_option('tartarus_crawl_list');
        add_option('tartarus_crawl_list', array());
    }*/
    $tartarus_ReCaptcha_Settings = array(
        'secret_key' => '',
        'site_key' => '',
        'recaptcha_enabled' => '',
        'recaptcha_comment' => '',
        'recaptcha_signup' => '',
        'recaptcha_login' => '',
        'recaptcha_disable_logged_in' => '',
        'recaptcha_lostpassword' => '',
        'lost_password_spam' => 'Please Do not Spam!',
        'lost_password_incorrect' => 'Please Recheck the Captcha!',
        'log_in_spam' => 'Please Do not Spam!',
        'log_in_incorrect' => 'Please Recheck the Captcha!',
        'comment_spam' => 'Please Do not Spam!',
        'comment_incorrect' => 'Please Recheck the Captcha!',
        'sign_up_incorrect' => 'Please Recheck the Captcha!',
        'sign_up_spam' => 'Please Do not Spam!',
        'recaptcha_theme' => 'Light',
        'recaptcha_language' => 'en'
    );
    if (!get_option('tartarus_ReCaptcha_Settings')) {
        add_option('tartarus_ReCaptcha_Settings', $tartarus_ReCaptcha_Settings);
    }/* else {
        delete_option('tartarus_ReCaptcha_Settings');
        add_option('tartarus_ReCaptcha_Settings', $tartarus_ReCaptcha_Settings);
    }*/
    $tartarus_Meta_Settings = array(
        'seo_noindex_posts' => '',
        'seo_noindex_pages' => '',
        'seo_noindex_media' => '',
        'seo_noindex_category' => 'on',
        'seo_noindex_archive' => 'on',
        'seo_noindex_search' => '',
        'seo_noindex_tax' => '',
        'seo_noindex_nf' => '',
        'seo_noindex_home' => '',
        'seo_noindex_tag' => 'on',
        'seo_nofollow_category' => '',
        'seo_nofollow_archive' => '',
        'seo_nofollow_search' => '',
        'seo_nofollow_tax' => '',
        'seo_nofollow_nf' => '',
        'seo_nofollow_home' => '',
        'seo_nofollow_tag' => '',
        'seo_noodp_category' => '',
        'seo_noodp_archive' => '',
        'seo_noodp_search' => '',
        'seo_noodp_tax' => '',
        'seo_noodp_nf' => '',
        'seo_noodp_home' => '',
        'seo_noodp_tag' => '',
        'seo_noydir_category' => '',
        'seo_noydir_archive' => '',
        'seo_noydir_search' => '',
        'seo_noydir_tax' => '',
        'seo_noydir_nf' => '',
        'seo_noydir_home' => '',
        'seo_noydir_tag' => '',
        'seo_nofollow_posts' => '',
        'seo_nofollow_pages' => '',
        'seo_nofollow_media' => '',
        'seo_noodp_posts' => '',
        'seo_noodp_pages' => '',
        'seo_noodp_media' => '',
        'seo_noydir_posts' => '',
        'seo_noydir_pages' => '',
        'seo_noydir_media' => '',
        'seo_misc' => 'on'
    );
    if (!get_option('tartarus_Meta_Settings')) {
        add_option('tartarus_Meta_Settings', $tartarus_Meta_Settings);
    }/* else {
        delete_option('tartarus_Meta_Settings');
        add_option('tartarus_Meta_Settings', $tartarus_Meta_Settings);
    }*/
}

register_activation_hook(__FILE__, 'tartarus_check_version');
function tartarus_check_version()
{
    global $wp_version;
    if (!current_user_can('activate_plugins')) {
        echo '<p>' . sprintf(__('You are not allowed to activate plugins!', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    $php_version_required = '5.3';
    $wp_version_required  = '2.7';
    
    if (version_compare(PHP_VERSION, $php_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    
    if (version_compare($wp_version, $wp_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to get the latest version of WordPress .', 'oe-sb'), $wp_version_required) . '</p>';
        die;
    }
}

add_action('admin_init', 'tartarus_register_mysettings');
function tartarus_register_mysettings()
{
    register_setting('tartarus_option_group', 'tartarus_Main_Settings');
    register_setting('tartarus_option_group2', 'tartarus_crawl_list');
    register_setting('tartarus_option_group3', 'tartarus_ReCaptcha_Settings');
    register_setting('tartarus_option_group4', 'tartarus_Meta_Settings');
}

function tartarus_get_plugin_url()
{
    return plugins_url('', __FILE__);
}

function tartarus_get_file_url($url)
{
    return tartarus_get_plugin_url() . '/' . $url;
}

add_action('init', 'tartarus_checker');
add_action('init', 'tartarus_recaptcha_integrator');
function tartarus_recaptcha_integrator()
{
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['tartarus_enabled']) && $tartarus_Main_Settings['tartarus_enabled'] === 'on') {
        if(!is_admin() || ($GLOBALS['pagenow'] === 'admin.php' && !empty($_REQUEST['page']) && $_REQUEST['page'] === 'tartarus_recaptcha_integrition'))
        {
            $tartarus_ReCaptcha_Settings = get_option('tartarus_ReCaptcha_Settings', false);
            if (isset($tartarus_ReCaptcha_Settings['recaptcha_enabled']) && $tartarus_ReCaptcha_Settings['recaptcha_enabled'] === 'on') {
                wp_enqueue_script('tartarus-recaptcha', 'https://www.google.com/recaptcha/api.js?hl=' . $tartarus_ReCaptcha_Settings['recaptcha_language'], array(), '1.0.0', true);
                
                if (isset($tartarus_ReCaptcha_Settings['recaptcha_comment']) && $tartarus_ReCaptcha_Settings['recaptcha_comment'] === 'on') {
                    if (isset($tartarus_ReCaptcha_Settings['recaptcha_disable_logged_in']) && $tartarus_ReCaptcha_Settings['recaptcha_disable_logged_in'] === 'on') {
                        if (!is_user_logged_in()) {
                            if ($GLOBALS['pagenow'] !== 'wp-login.php') {
                                if (isset($tartarus_ReCaptcha_Settings['recaptcha_enabled']) && $tartarus_ReCaptcha_Settings['recaptcha_enabled'] === 'on') {
                                    wp_enqueue_script('tartarus_enque_script', tartarus_get_file_url('res/recaptcha.js'), array(
                                        'jquery'
                                    ), '1.0.0', true);
                                    $settings = array(
                                        'url_to_php' => tartarus_get_file_url('res/tartarus_google_captcha.php'),
                                        'secret' => $tartarus_ReCaptcha_Settings['secret_key'],
                                        'incorrect' => $tartarus_ReCaptcha_Settings['comment_incorrect'],
                                        'spam' => $tartarus_ReCaptcha_Settings['comment_spam']
                                    );
                                    wp_localize_script('tartarus_enque_script', 'settings', $settings);
                                    add_filter('comment_form', 'tartarus_add_comment_captcha');
                                }
                            }
                        }
                    } else {
                        if ($GLOBALS['pagenow'] !== 'wp-login.php') {
                            if (isset($tartarus_ReCaptcha_Settings['recaptcha_enabled']) && $tartarus_ReCaptcha_Settings['recaptcha_enabled'] === 'on') {
                                wp_enqueue_script('tartarus_enque_script', tartarus_get_file_url('res/recaptcha.js'), array(
                                    'jquery'
                                ), '1.0.0', true);
                                $settings = array(
                                    'url_to_php' => tartarus_get_file_url('res/tartarus_google_captcha.php'),
                                    'secret' => $tartarus_ReCaptcha_Settings['secret_key'],
                                    'incorrect' => $tartarus_ReCaptcha_Settings['comment_incorrect'],
                                    'spam' => $tartarus_ReCaptcha_Settings['comment_spam']
                                );
                                wp_localize_script('tartarus_enque_script', 'settings', $settings);
                                add_filter('comment_form', 'tartarus_add_comment_captcha');
                            }
                        }
                    }
                }
                if (isset($tartarus_ReCaptcha_Settings['recaptcha_login']) && $tartarus_ReCaptcha_Settings['recaptcha_login'] === 'on') {
                    if ($GLOBALS['pagenow'] === 'wp-login.php' && empty($_REQUEST['action'])) {
                        wp_enqueue_script('tartarus_enque_script', tartarus_get_file_url('res/recaptcha_login.js'), array(
                            'jquery'
                        ), '1.0.0', true);
                        $settings = array(
                            'url_to_php' => tartarus_get_file_url('res/tartarus_google_captcha.php'),
                            'secret' => $tartarus_ReCaptcha_Settings['secret_key'],
                            'incorrect' => $tartarus_ReCaptcha_Settings['log_in_incorrect'],
                            'spam' => $tartarus_ReCaptcha_Settings['log_in_spam']
                        );
                        wp_localize_script('tartarus_enque_script', 'settings', $settings);
                        add_filter('login_form', 'tartarus_add_comment_captcha');
                    }
                }
                if (isset($tartarus_ReCaptcha_Settings['recaptcha_signup']) && $tartarus_ReCaptcha_Settings['recaptcha_signup'] === 'on') {
                    if ($GLOBALS['pagenow'] === 'wp-login.php' && !empty($_REQUEST['action']) && $_REQUEST['action'] === 'register') {
                        wp_enqueue_script('tartarus_enque_script', tartarus_get_file_url('res/recaptcha_register.js'), array(
                            'jquery'
                        ), '1.0.0', true);
                        $settings = array(
                            'url_to_php' => tartarus_get_file_url('res/tartarus_google_captcha.php'),
                            'secret' => $tartarus_ReCaptcha_Settings['secret_key'],
                            'incorrect' => $tartarus_ReCaptcha_Settings['sign_up_incorrect'],
                            'spam' => $tartarus_ReCaptcha_Settings['sign_up_spam']
                        );
                        wp_localize_script('tartarus_enque_script', 'settings', $settings);
                        add_filter('register_form', 'tartarus_add_comment_captcha');
                    }
                }
                if (isset($tartarus_ReCaptcha_Settings['recaptcha_lostpassword']) && $tartarus_ReCaptcha_Settings['recaptcha_lostpassword'] === 'on') {
                    if ($GLOBALS['pagenow'] === 'wp-login.php' && !empty($_REQUEST['action']) && $_REQUEST['action'] === 'lostpassword') {
                        wp_enqueue_script('tartarus_enque_script', tartarus_get_file_url('res/recaptcha_lostpassword.js'), array(
                            'jquery'
                        ), '1.0.0', true);
                        $settings = array(
                            'url_to_php' => tartarus_get_file_url('res/tartarus_google_captcha.php'),
                            'secret' => $tartarus_ReCaptcha_Settings['secret_key'],
                            'incorrect' => $tartarus_ReCaptcha_Settings['lost_password_incorrect'],
                            'spam' => $tartarus_ReCaptcha_Settings['lost_password_spam']
                        );
                        wp_localize_script('tartarus_enque_script', 'settings', $settings);
                        add_filter('lostpassword_form', 'tartarus_add_comment_captcha');
                    }
                }
            }
        }
    }
}

function tartarus_add_comment_captcha()
{
    $tartarus_ReCaptcha_Settings = get_option('tartarus_ReCaptcha_Settings', false);
    $key                         = $tartarus_ReCaptcha_Settings['site_key'];
    $theme                       = $tartarus_ReCaptcha_Settings['recaptcha_theme'];
    echo '<div class="g-recaptcha" data-sitekey="' . $key . '" data-theme="' . $theme . '" style="transform:scale(0.90);-webkit-transform:scale(0.90);transform-origin:0 0;-webkit-transform-origin:0 0;"></div>';
}
add_action('admin_init', 'tartarus_delete_crawler_entry');
add_action('admin_init', 'tartarus_robots_main');
add_action('template_redirect', 'tartarus_gates_main');
function tartarus_gates_main()
{
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['tartarus_enabled']) && $tartarus_Main_Settings['tartarus_enabled'] === 'on') {
        if (isset($tartarus_Main_Settings['enable_trap']) && $tartarus_Main_Settings['enable_trap'] === 'on') {
            add_action('wp_footer', 'tartarus_set_up_trap');
        }
    }
}
add_action('init', 'tartarus_honeypot_method');
function tartarus_honeypot_method()
{
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['tartarus_enabled']) && $tartarus_Main_Settings['tartarus_enabled'] === 'on') {
        if (isset($tartarus_Main_Settings['honeypot_method']) && $tartarus_Main_Settings['honeypot_method'] === 'on') {
            add_filter('preprocess_comment', 'tartarus_intercept_comment');
            add_action('comment_form_logged_in_after', 'tartarus_additional_fields');
            add_action('comment_form_after_fields', 'tartarus_additional_fields');
        }
    }
}
function tartarus_intercept_comment(array $data)
{
    if (!isset($_POST['the_comment_author_url']) || $_POST['the_comment_author_url'] == '') {
        return $data;
    } else {
        $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
        if (isset($tartarus_Main_Settings['honeypot_method_ban']) && $tartarus_Main_Settings['honeypot_method_ban'] === 'on') {
            if (!tartarus_check_whitelist()) {
                if (!tartarus_recognize_spider()) {
                    tartarus_ban('CommentSpam');
                }
            }
        }
        
        $message = $tartarus_Main_Settings['honeypot_method_text'];
        $title   = 'Tartarus Worpress Plugin Spam Blocker';
        $args    = array(
            'response' => 200
        );
        wp_die($message, $title, $args);
        exit(0);
    }
}
function tartarus_additional_fields()
{
    echo '<p class="the_comment_author_url">' . '<input id="the_comment_author_url" name="the_comment_author_url" type="text" style="display:none"/></p>';
}
function tartarus_robots_main()
{
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['tartarus_enabled']) && $tartarus_Main_Settings['tartarus_enabled'] === 'on') {
        if (isset($tartarus_Main_Settings['enable_trap']) && $tartarus_Main_Settings['enable_trap'] === 'on') {
            if (isset($tartarus_Main_Settings['add_robots']) && $tartarus_Main_Settings['add_robots'] === 'on') {
                $robots = ABSPATH . 'robots.txt';
                if (file_exists($robots)) {
                    $text3 = file_get_contents($robots);
                    if (stripos($text3, 'Disallow: /wp/?tartarus') === false) {
                        file_put_contents($robots, PHP_EOL . 'User-agent: *' . PHP_EOL . 'Disallow: /wp/?tartarus ' . PHP_EOL, FILE_APPEND | LOCK_EX);
                    }
                } else {
                    file_put_contents($robots, PHP_EOL . 'User-agent: *' . PHP_EOL . 'Disallow: /wp/?tartarus ' . PHP_EOL);
                }
                add_filter('robots_txt', 'tartarus_addToRoboText');
            } else {
                $robots = ABSPATH . 'robots.txt';
                if (file_exists($robots)) {
                    $text3 = file_get_contents($robots);
                    if (stripos($text3, PHP_EOL . 'User-agent: *' . PHP_EOL . 'Disallow: /wp/?tartarus ' . PHP_EOL) !== false) {
                        $text3 = str_replace(PHP_EOL . 'User-agent: *' . PHP_EOL . 'Disallow: /wp/?tartarus ' . PHP_EOL, '', $text3);
                        file_put_contents($robots, $text3);
                    }
                }
            }
        }
        $append_to_htaccess = '
#Tartarus begin bad bot blocker
SetEnvIfNoCase ^User-Agent$ .*(aesop_com_spiderman|alexibot|backweb|bandit|batchftp|bigfoot) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(black.?hole|blackwidow|blowfish|botalot|buddy|builtbottough|bullseye) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(capture|fetch|finder|harvest|Java|larbin|libww|library|link|nutch|Retrieve) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(cheesebot|cherrypicker|chinaclaw|collector|copier|copyrightcheck|crawl) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(cosmos|crescent|curl|custo|da|diibot|disco|dittospyder|dragonfly) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(drip|easydl|ebingbong|ecatch|eirgrabber|emailcollector|emailsiphon) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(emailwolf|erocrawler|exabot|eyenetie|filehound|flashget|flunky) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(frontpage|getright|getweb|go.?zilla|go-ahead-got-it|gotit|grabnet) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(grafula|harvest|hloader|hmview|httplib|httrack|humanlinks|ilsebot) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(infonavirobot|infotekies|intelliseek|interget|iria|jennybot|jetcar) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(joc|justview|jyxobot|kenjin|keyword|larbin|leechftp|lexibot|lftp|libweb) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(likse|linkscan|linkwalker|lnspiderguy|lwp|magnet|mag-net|markwatch) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(mata.?hari|memo|microsoft.?url|midown.?tool|miixpc|mirror|missigua|mrsputnik) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(mister.?pix|moget|mozilla.?newt|nameprotect|navroad|backdoorbot|nearsite) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(net.?vampire|netants|netcraft|netmechanic|netspider|nextgensearchbot) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(attach|nicerspro|nimblecrawler|npbot|octopus|offline.?explorer) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(offline.?navigator|openfind|outfoxbot|pagegrabber|papa|pavuk) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(pcbrowser|php.?version.?tracker|pockey|propowerbot|prowebwalker) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(psbot|pump|queryn|recorder|realdownload|reaper|reget|true_robot) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(repomonkey|rma|internetseer|sitesnagger|siphon|slysearch|smartdownload) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(snake|snapbot|snoopy|sogou|spacebison|spankbot|spanner|sqworm|superbot) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(scraper|siphon|spider|tool|superhttp|surfbot|asterias|suzuran|szukacz|takeout|teleport) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(telesoft|the.?intraformant|thenomad|tighttwatbot|titan|urldispatcher) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(turingos|turnitinbot|urly.?warning|vacuum|vci|voideye|whacker) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(widow|wisenutbot|wwwoffle|xaldon|xenu|zeus|zyborg|anonymouse) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(craftbot|download|extract|stripper|sucker|ninja|clshttp|webspider|leacher|coll?ector|grabber|webpictures) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(libwww-perl|aesop_com_spiderman) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(libwww-perl|Purebot|Sosospider|AboutUsBot|Johnny5|Python-urllib|Yeti|TurnitinBot) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(GoScraper|Kehalim|DoCoMo|SurveyBot|spbot|BDFetch|EasyDL|CamontSpider|Chilkat|Z?mEu) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*(GoScraper|Kehalim|DoCoMo|SurveyBot|spbot|BDFetch|EasyDL|CamontSpider|Chilkat|Z?mEu) HTTP_SAFE_BADBOT
SetEnvIfNoCase ^User-Agent$ .*web(zip|emaile|enhancer|fetch|go.?is|auto|bandit|clip|copier|master|reaper|sauger|site.?quester|whack) HTTP_SAFE_BADBOT
<Limit GET POST>
Order Allow,Deny
Allow from all
Deny from env=HTTP_SAFE_BADBOT
</Limit>
#Tartarus end bad bot blocker
';
        if (isset($tartarus_Main_Settings['htaccess_block']) && $tartarus_Main_Settings['htaccess_block'] === 'on') {
            $htaccess = ABSPATH . '.htaccess';
            if (file_exists($htaccess)) {
                    $text3 = file_get_contents($htaccess);
                    if (stripos($text3, $append_to_htaccess) === false) {
                        file_put_contents($htaccess, $append_to_htaccess, FILE_APPEND | LOCK_EX);
                    }
                } else {
                    file_put_contents($htaccess, $append_to_htaccess);
                }
        }
        else
        {
            $htaccess = ABSPATH . '.htaccess';
            if (file_exists($htaccess)) {
                    $text3 = file_get_contents($htaccess);
                    if (stripos($text3, $append_to_htaccess) !== false) {
                        $text3 = str_replace($append_to_htaccess, "", $text3);
                        file_put_contents($htaccess, $text3);
                    }
                }
        }
    }
}
function tartarus_make_js_email($email)
{ 
    $character_set = '+-.0123456789@ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz';
    $key = str_shuffle($character_set); $cipher_text = ''; $id = 'e'.rand(1,999999999);
    for ($i=0;$i<strlen($email);$i+=1) $cipher_text.= $key[strpos($character_set,$email[$i])];
    $script = 'var a="'.$key.'";var b=a.split("").sort().join("");var c="'.$cipher_text.'";var d="";';
    $script.= 'for(var e=0;e<c.length;e++)d+=b.charAt(a.indexOf(c.charAt(e)));';
    $script.= 'document.getElementById("'.$id.'").innerHTML="<a href=\\"mailto:"+d+"\\">"+d+"</a>"';
    $script = "eval(\"".str_replace(array("\\",'"'),array("\\\\",'\"'), $script)."\")"; 
    $script = '<script type="text/javascript">/*<![CDATA[*/'.$script.'/*]]>*/</script>';
    return '<span style="display:block;" id="'.$id.'">[javascript protected email address]</span>'.$script;
}
add_shortcode('tartarus_add_secure_email', 'tartarus_add_secure_email');
function tartarus_add_secure_email($atts)
{
	$myEmail = (isset($atts['email']) && !empty($atts['email']))? $atts['email'] : "";
	if(!empty($myEmail))
    {
        if ( ! is_email( $myEmail ) ) 
        {
            return $myEmail;
        }
        return tartarus_make_js_email($myEmail);
	}
}

function tartarus_addToRoboText($robotext)
{
    $additions = PHP_EOL . 'User-agent: *' . PHP_EOL . 'Disallow: /wp/?tartarus ' . PHP_EOL;
    return $robotext . $additions;
}
function tartarus_is_admin()
{
    return in_array('administrator', wp_get_current_user()->roles);
}
function tartarus_delete_crawler_entry()
{
    if (!tartarus_is_admin())
        return false;
    $del = isset($_GET['del']) ? $_GET['del'] : '';
    if ($del == '')
        return false;
    if ($del == 'all') {
        $tartarus_crawl_list = array();
    } else {
        $tartarus_crawl_list = get_option('tartarus_crawl_list');
        unset($tartarus_crawl_list[$del]);
    }
    update_option('tartarus_crawl_list', $tartarus_crawl_list);
}
add_action('wp_ajax_tartarus_my_action', 'tartarus_my_action_callback');
function tartarus_my_action_callback()
{
    $tartarus_crawl_list   = get_option('tartarus_crawl_list');
    $new_IP                = $_POST['new_IP'];
    $new_UA                = $_POST['new_UA'];
    $date                  = date('Y/m/d h:i:s a', current_time('timestamp'));
    $vars                  = array(
        $new_IP,
        'manual',
        'manual',
        $new_UA,
        'manual',
        'manual',
        'manual',
        $date,
        'Manual'
    );
    $tartarus_crawl_list[] = $vars;
    $rez                   = update_option('tartarus_crawl_list', $tartarus_crawl_list);
    echo $rez;
    die();
}
function tartarus_recursive_delete($directory)
{
    foreach (glob("{$directory}/*") as $file) {
        if (!is_dir($file)) {
            unlink($file);
        }
    }
}
add_action('wp_ajax_tartarus_my_action2', 'tartarus_my_action_callback2');
function tartarus_my_action_callback2()
{
    $dir     = plugin_dir_path(__FILE__);
    $ua_file = $dir . 'logs';
    if (file_exists($ua_file)) {
        tartarus_recursive_delete($ua_file);
    }
    echo '0';
    die();
}
add_action('all_admin_notices', 'tartarus_add_info');
function tartarus_add_info()
{
    if (!tartarus_is_admin())
        return false;
    $expand = isset($_GET['expand']) ? $_GET['expand'] : '';
    if ($expand == '')
        return false;
    $tartarus_crawl_list = get_option('tartarus_crawl_list');
    echo '<p><b>More info for the entry with IP: ' . $tartarus_crawl_list[$expand][0] . '</b><br/>';
    echo 'User Agent: ' . $tartarus_crawl_list[$expand][3] . '<br/>';
    echo 'Request URI: ' . $tartarus_crawl_list[$expand][1] . '<br/>';
    echo 'Query string: ' . $tartarus_crawl_list[$expand][2] . '<br/>';
    echo 'Referrer: ' . $tartarus_crawl_list[$expand][4] . '<br/>';
    echo 'Protocol: ' . $tartarus_crawl_list[$expand][5] . '<br/>';
    echo 'Method: ' . $tartarus_crawl_list[$expand][6] . '<br/>';
    echo 'Date: ' . $tartarus_crawl_list[$expand][7] . '<br/>';
    echo 'Ban Reason: ' . $tartarus_crawl_list[$expand][8] . '</p>';
}

function tartarus_is_login()
{
    
    return in_array($GLOBALS['pagenow'], array(
        'wp-login.php',
        'wp-register.php'
    ));
    
}

function tartarus_check_whitelist()
{
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['excepted_bots'])) {
        $excepted_bots = $tartarus_Main_Settings['excepted_bots'];
        $excepted_bots = array_filter(array_map('trim', explode(',', $excepted_bots)));
        $excepted_bots = implode('|', $excepted_bots);
    } else {
        $excepted_bots = '';
    }
    if (isset($tartarus_Main_Settings['excepted_ips'])) {
        $excepted_ips = $tartarus_Main_Settings['excepted_ips'];
        $excepted_ips = array_filter(array_map('trim', explode(',', $excepted_ips)));
        $excepted_ips = implode('|', $excepted_ips);
    } else {
        $excepted_ips = '';
    }
    
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
    } else {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $real_ip_adress = $_SERVER['REMOTE_ADDR'];
        }
    }
    if (!empty($excepted_bots) && preg_match("/(" . $excepted_bots . ")/i", $user_agent, $matches))
        return true;
    if (!empty($excepted_ips) && preg_match("/(" . $excepted_ips . ")/i", $real_ip_adress, $matches))
        return true;
    
    return false;
    
}
function tartarus_recognize_spider()
{
    $tartarus_crawl_list    = get_option('tartarus_crawl_list');
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['user_agent_check']) && $tartarus_Main_Settings['user_agent_check'] === 'on') {
        $userAgent = true;
    } else {
        $userAgent = false;
    }
    if (isset($tartarus_crawl_list) && $tartarus_crawl_list != '') {
        $vars = tartarus_get_bot_specs();
        list($ip_address, $request_uri, $query_string, $user_agent, $referrer, $protocol, $method, $date, $reason) = $vars;
        foreach ($tartarus_crawl_list as $banned_bot_name => $banned_bot) {
            list($banned_ip_address, $banned_request_uri, $banned_query_string, $banned_user_agent, $banned_referrer, $banned_protocol, $banned_method, $banned_date) = $banned_bot;
            if ($banned_ip_address != '') {
                if ($userAgent == true) {
                    
                    if (preg_match('#' . $banned_ip_address . '#i', $ip_address, $is_match) && preg_match('#' . $banned_user_agent . '#i', $user_agent, $is_match2)) {
                        return true;
                    }
                } else {
                    if (preg_match('#' . $banned_ip_address . '#i', $ip_address, $is_match)) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}
function tartarus_checker()
{
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['tartarus_enabled']) && $tartarus_Main_Settings['tartarus_enabled'] === 'on') {
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        preg_match('/twitterbot|slurp|ia_archiver|facebookexternalhit|facebot|googlebot|mediapartners|adsbot|Yahoo|baidu|yandex|yahooseeker|yahoobot|msnbot|watchmouse|pingdom|feedfetcher-google|bingbot|bingpreview/i', $user_agent, $goodbot);
        if (isset($tartarus_Main_Settings['redirect_goodbot_names']) && $tartarus_Main_Settings['redirect_goodbot_names'] !== '') {
            $names = $tartarus_Main_Settings['redirect_goodbot_names'];
            $names = str_replace(",", "|", $names);
            if (preg_match('#' . $names . '#i', $user_agent, $goodbot2)) {
                $goodbot = true;
            }
        }
        preg_match('#bot|SiteLockSpider|crawler|archiver|transcoder|spider|uptime|validator|fetcher|MJ12bot|Ezooms|AhrefsBot|FHscan|Acunetix|Zyborg|ZmEu|Zeus|Xenu|Xaldon|WWW-Collector-E|WWWOFFLE|WISENutbot|Widow|Whacker|WebZIP|WebWhacker|WebStripper|Webster|Website\ Quester|Website\ eXtractor|WebSauger|WebReaper|WebmasterWorldForumBot|WebLeacher|Web.Image.Collector|WebGo\ IS|WebFetch|WebEnhancer|WebEMailExtrac|WebCopier|Webclipping.com|WebBandit|WebAuto|Web\ Sucker|Web\ Image\ Collector|VoidEYE|VCI|Vacuum|URLy.Warning|TurnitinBot|turingos|True_Robot|Titan|TightTwatBot|TheNomad|The.Intraformant|TurnitinBot/1.5|Telesoft|Teleport|tAkeOut|Szukacz/1.4|suzuran|Surfbot|SuperHTTP|SuperBot|Sucker|Stripper|Sqworm|spanner|SpankBot|SpaceBison|sogou|Snoopy|Snapbot|Snake|SmartDownload|SlySearch|SiteSnagger|Siphon|RMA|RepoMonkey|ReGet|Recorder|Reaper|RealDownload|QueryN.Metasearch|Pump|psbot|ProWebWalker|ProPowerBot/2.14|Pockey|PHP\ version\ tracker|pcBrowser|pavuk|Papa\ Foto|PageGrabber|OutfoxBot|Openfind|Offline\ Navigator|Offline\ Explorer|Octopus|NPbot|Ninja|NimbleCrawler|niki-bot|NICErsPRO|NG|NextGenSearchBot|NetZIP|Net\ Vampire|NetSpider|NetMechanic|Netcraft|NetAnts|NearSite|Navroad|NAMEPROTECT|Mozilla.*NEWT|Mozilla/3.Mozilla/2.01|moget|Mister\ PiX|Missigua\ Locator|Mirror|MIIxpc|MIDown\ tool|Microsoft\ URL\ Control|Microsoft.URL|Memo|Mata.Hari|Mass\ Downloader|MarkWatch|Mag-Net|Magnet|LWP::Simple|lwp-trivial|LinkWalker|LNSpiderguy|LinkScan/8.1a.Unix|LinkextractorPro|likse|libWeb/clsHTTP|lftp|LexiBot|larbin|Key2.Density|Kenjin.Spider|Jyxobot|JustView|JOC|JetCar|JennyBot|Jakarta|Iria|Internet\ Ninja|InterGET|Intelliseek|InfoTekies|InfoNaviRobot|Indy\ Library|Image\ Sucker|Image\ Stripper|IlseBot|humanlinks|HTTrack|HMView|hloader|Harvest|Grafula|GrabNet|gotit|Go-Ahead-Got-It|FrontPage|flunky|Foobot|EyeNetIE|Extractor|Express\ WebPictures|Exabot|EroCrawler|EmailWolf|EmailSiphon|EmailCollector|EirGrabber|ebingbong|EasyDL|eCatch|Drip|dragonfly|Download\ Wonder|Download\ Devil|Download\ Demon|DittoSpyder|DIIbot|DISCo|AIBOT|Aboundex|Custo|Crescent|cosmos|CopyRightCheck|Copier|Collector|ChinaClaw|CherryPicker|CheeseBot|Cegbfeieh|BunnySlippers|Bullseye|BuiltBotTough|Buddy|BotALot|BlowFish|BlackWidow|Black.Hole|Bigfoot|BatchFTP|Bandit|BackWeb|BackDoorBot|80legs|360Spider|Java|Cogentbot|Alexibot|asterias|attach|eStyle|WebCrawler|Dumbot|CrocCrawler|ASPSeek|AcoiRobot|DuckDuckBot|BLEXBot|Ips Agent|bot|crawl|spider|outbrain|008|192.comAgent|2ip\.ru|404checker|^bluefish |^FDM |^git|^Goose|^HTTPClient|^Java|^Jetty|^Mget|^Microsoft URL Control|^NG\/[0-9\.]|^NING|^PHP\/[0-9]|^RMA|^Ruby|Ruby\/[0-9]|^scrutiny|^VSE\/[0-9]|^WordPress\.com|^XRL\/[0-9]|a3logics\.in|A6-Indexer|a\.pr-cy\.ru|Aboundex|aboutthedomain|Accoona|acoon|acrylicapps\.com\/pulp|adbeat|AddThis|ADmantX|adressendeutschland|Advanced Email Extractor v|agentslug|AHC|aihit|aiohttp|Airmail|akula|alertra|alexa site audit|Alibaba\.Security\.Heimdall|alyze\.info|amagit|AndroidDownloadManager|Anemone|Ant\.com|Anturis Agent|AnyEvent-HTTP|Apache-HttpClient|AportWorm\/[0-9]|AppEngine-Google|Arachmo|arachnode|Arachnophilia|archive-com|aria2|asafaweb.com|AskQuickly|Astute|asynchttp|autocite|Autonomy|B-l-i-t-z-B-O-T|Backlink-Ceck\.de|Bad-Neighborhood|baypup\/[0-9]|baypup\/colbert|BazQux|BCKLINKS|BDFetch|BegunAdvertising|bibnum\.bnf|BigBozz|biglotron|BingLocalSearch|binlar|biz_Directory|Blackboard Safeassign|Bloglovin|BlogPulseLive|BlogSearch|Blogtrottr|boitho\.com-dc|BPImageWalker|Braintree-Webhooks|Branch Metrics API|Branch-Passthrough|Browsershots|BUbiNG|Butterfly|BuzzSumo|CakePHP|CapsuleChecker|CaretNail|cb crawl|CC Metadata Scaper|Cerberian Drtrs|CERT\.at-Statistics-Survey|cg-eye|changedetection|Charlotte|CheckHost|chkme\.com|CirrusExplorer|CISPA Vulnerability Notification|CJNetworkQuality|clips\.ua\.ac\.be|Cloud mapping experiment|CloudFlare-AlwaysOnline|Cloudinary\/[0-9]|cmcm\.com|coccoc|CommaFeed|Commons-HttpClient|Comodo SSL Checker|contactbigdatafr|convera|copyright sheriff|cosmos\/[0-9]|Covario-IDS|CrawlForMe\/[0-9]|cron-job\.org|Crowsnest|curb|Curious George|curl|cuwhois\/[0-9]|CyberPatrol|cybo\.com|DareBoost|DataparkSearch|dataprovider|Daum(oa)?[ \/][0-9]|DeuSu|developers\.google\.com\/\+\/web\/snippet|Digg|Dispatch|dlvr|DNS-Tools Header-Analyzer|DNSPod-reporting|docoloc|DomainAppender|dotSemantic|downforeveryoneorjustme|downnotifier\.com|DowntimeDetector|Dragonfly File Reader|drupact|Drupal (\+http:\/\/drupal\.org\/)|dubaiindex|EARTHCOM|Easy-Thumb|ec2linkfinder|eCairn-Grabber|ECCP|ElectricMonk|elefent|EMail Exractor|EmailWolf|Embed PHP Library|Embedly|europarchive\.org|evc-batch\/[0-9]|EventMachine HttpClient|Evidon|Evrinid|ExactSearch|ExaleadCloudview|Excel|Exploratodo|ezooms|facebookplatform|fairshare|Faraday v|Faveeo|Favicon downloader|FavOrg|Feed Wrangler|Feedbin|FeedBooster|FeedBucket|FeedBurner|FeedChecker|Feedly|Feedspot|feeltiptop|Fetch API|Fetch\/[0-9]|Fever\/[0-9]|findlink|findthatfile|Flamingo_SearchEngine|FlipboardBrowserProxy|FlipboardProxy|FlipboardRSS|fluffy|flynxapp|forensiq|FoundSeoTool\/[0-9]|free thumbnails|FreeWebMonitoring SiteChecker|Funnelback|g00g1e\.net|GAChecker|geek-tools|Genderanalyzer|Genieo|GentleSource|GetLinkInfo|getprismatic\.com|GetURLInfo\/[0-9]|GigablastOpenSource|Go [\d\.]* package http|Go-http-client|GomezAgent|gooblog|Goodzer\/[0-9]|Google favicon|Google Keyword Suggestion|Google Keyword Tool|Google Page Speed Insights|Google PP Default|Google Search Console|Google Web Preview|Google-Adwords|Google-Apps-Script|Google-Calendar-Importer|Google-HTTP-Java-Client|Google-Publisher-Plugin|Google-SearchByImage|Google-Site-Verification|Google-Structured-Data-Testing-Tool|google_partner_monitoring|GoogleDocs|GoogleHC|GoogleProducer|GoScraper|GoSpotCheck|GoSquared-Status-Checker|gosquared-thumbnailer|GotSiteMonitor|Grammarly|grouphigh|grub-client|GTmetrix|gvfs|HAA(A)?RTLAND http client|Hatena|hawkReader|HEADMasterSEO|HeartRails_Capture|heritrix|hledejLevne\.cz\/[0-9]|Holmes|HootSuite Image proxy|Hootsuite-WebFeed\/[0-9]|HostTracker|ht:\/\/check|htdig|HTMLParser|HTTP-Header-Abfrage|http-kit|HTTP-Tiny|HTTP_Compression_Test|http_request2|http_requester|HttpComponents|httphr|HTTPMon|httpscheck|httpssites_power|httpunit|HttpUrlConnection|httrack|hosterstats|huaweisymantec|HubPages.*crawlingpolicy|HubSpot Connect|HubSpot Marketing Grader|HyperZbozi.cz Feeder|ichiro|IdeelaborPlagiaat|IDG Twitter Links Resolver|IDwhois\/[0-9]|Iframely|igdeSpyder|IlTrovatore|ImageEngine|Imagga|InAGist|inbound\.li parser|InDesign|infegy|infohelfer|InfoWizards Reciprocal Link System PRO|inpwrd\.com|Integrity|integromedb|internet_archive|InternetSeer|internetVista monitor|IODC|IOI|ips-agent|iqdb|Irokez|isitup\.org|iskanie|iZSearch|janforman|Jigsaw|Jobboerse|jobo|Jobrapido|KeepRight OpenStreetMap Checker|KickFire|KimonoLabs|knows\.is|kouio|KrOWLer|kulturarw3|KumKie|L\.webis|Larbin|LayeredExtractor|LibVLC|libwww|Liferea|link checker|Link Valet|link_thumbnailer|linkCheck|linkdex|LinkExaminer|linkfluence|linkpeek|LinkTiger|LinkWalker|Lipperhey|livedoor ScreenShot|LoadImpactPageAnalyzer|LoadImpactRload|LongURL API|looksystems\.net|ltx71|lwp-trivial|lycos|LYT\.SR|mabontland|MagpieRSS|Mail.Ru|MailChimp\.com|Mandrill|marketinggrader|MegaIndex\.ru|Melvil Rawi|MergeFlow-PageReader|MetaInspector|Metaspinner|MetaURI|Microsearch|Microsoft Office |Microsoft Windows Network Diagnostics|Mindjet|Miniflux|Mnogosearch|mogimogi|Mojolicious (Perl)|monitis|Monitority\/[0-9]|montastic|MonTools|Moreover|Morning Paper|mowser|Mrcgiguy|mShots|MVAClient|nagios|Najdi\.si|NETCRAFT|NetLyzer FastProbe|netresearch|NetShelter ContentScan|NetTrack|Netvibes|Neustar WPM|NeutrinoAPI|NewsBlur .*Finder|NewsGator|newsme|newspaper|NG-Search|nineconnections\.com|NLNZ_IAHarvester|Nmap Scripting Engine|node-superagent|node\.io|nominet\.org\.uk|Norton-Safeweb|Notifixious|notifyninja|nuhk|nutch|Nuzzel|nWormFeedFinder|Nymesis|Ocelli\/[0-9]|oegp|okhttp|Omea Reader|omgili|Online Domain Tools|OpenCalaisSemanticProxy|Openstat|OpenVAS|Optimizer|Orbiter|OrgProbe\/[0-9]|ow\.ly|ownCloud News|Page Analyzer|Page Valet|page2rss|page_verifier|PagePeeker|Pagespeed\/[0-9]|Panopta|panscient|parsijoo|PayPal IPN|Pcore-HTTP|Pearltrees|peerindex|Peew|PhantomJS|Photon|phpcrawl|phpservermon|Pi-Monster|Pingoscope|PingSpot|Pinterest|Pizilla|Ploetz \+ Zeller|Plukkie|PocketParser|Pompos|Porkbun|Port Monitor|postano|PostPost|postrank|PowerPoint|Priceonomics Analysis Engine|Prlog|probethenet|Project 25499|Promotion_Tools_www.searchenginepromotionhelp.com|prospectb2b|Protopage|proximic|PTST |PTST\/[0-9]+|Pulsepoint XT3 web scraper|Python-httplib2|python-requests|Python-urllib|Qirina Hurdler|Qseero|Qualidator.com SiteAnalyzer|Quora Link Preview|Qwantify|Radian6|RankSonicSiteAuditor|Readability|RealPlayer%20Downloader|RebelMouse|redback|Redirect Checker Tool|ReederForMac|request\.js|ResponseCodeTest\/[0-9]|RestSharp|RetrevoPageAnalyzer|Riddler|Rival IQ|Robosourcer|Robozilla\/[0-9]|ROI Hunter|SalesIntelligent|SauceNAO|SBIder|Scoop|scooter|ScoutJet|ScoutURLMonitor|Scrapy|Scrubby|SearchSight|semanticdiscovery|semanticjuice|SEO Browser|Seo Servis|seo-nastroj.cz|Seobility|SEOCentro|SeoCheck|SeopultContentAnalyzer|SEOstats|Server Density Service Monitoring|servernfo\.com|Seznam screenshot-generator|Shelob|Shoppimon Analyzer|ShoppimonAgent\/[0-9]|ShopWiki|ShortLinkTranslate|shrinktheweb|SilverReader|SimplePie|SimplyFast|Site-Shot|Site24x7|SiteBar|SiteCondor|siteexplorer\.info|SiteGuardian|Siteimprove\.com|Sitemap(s)? Generator|Siteshooter B0t|SiteTruth|sitexy\.com|SkypeUriPreview|slider\.com|SMRF URL Expander|SMUrlExpander|Snappy|SniffRSS|sniptracker|Snoopy|SortSite|spaziodati|Specificfeeds|speedy|SPEng|Spinn3r|spray-can|Sprinklr |spyonweb|Sqworm|SSL Labs|Rambler|Statastico|StatusCake|Stratagems Kumo|Stroke.cz|StudioFACA|suchen|summify|Super Monitoring|Surphace Scout|SwiteScraper|Symfony2 BrowserKit|SynHttpClient-Built|Sysomos|T0PHackTeam|Tarantula|teoma|terrainformatica\.com|The Expert HTML Source Viewer|theinternetrules|theoldreader\.com|Thumbshots|ThumbSniper|TinEye|Tiny Tiny RSS|topster|touche.com|Traackr.com|truwoGPS|tweetedtimes\.com|Tweetminster|Twikle|Twingly|Typhoeus|ubermetrics-technologies|uclassify|UdmSearch|UnwindFetchor|updated|Upflow|URLChecker|URLitor.com|urlresolver|Urlstat|UrlTrends Ranking Updater|Vagabondo|via ggpht\.com GoogleImageProxy|visionutils|vkShare|voltron|Vortex\/[0-9]|voyager|VSAgent\/[0-9]|VSB-TUO\/[0-9]|VYU2|w3af\.org|W3C-checklink|W3C-mobileOK|W3C_I18n-Checker|W3C_Unicorn|wangling|Wappalyzer|WbSrch|web-capture\.net|Web-Monitoring|Web-sniffer|Webauskunft|WebCapture|webcollage|WebCookies|WebCorp|WebDoc|WebFetch|WebImages|WebIndex|webkit2png|webmastercoffee|webmon |webscreenie|Webshot|Website Analyzer|websitepulse[+ ]checker|Websnapr|Websquash\.com|Webthumb\/[0-9]|WebThumbnail|WeCrawlForThePeace|WeLikeLinks|WEPA|WeSEE|wf84|wget|WhatsApp|WhatsMyIP|WhatWeb|Whibse|Whynder Magnet|Windows-RSS-Platform|WinHttpRequest|wkhtmlto|wmtips|Woko|WomlpeFactory|Word|WordPress|wotbox|WP Engine Install Performance API|WPScan|wscheck|WWW-Mechanize|www\.monitor\.us|XaxisSemanticsClassifier|Xenu Link Sleuth|XING-contenttabreceiver\/[0-9]|XmlSitemapGenerator|xpymep([0-9]?)\.exe|Y!J-(ASR|BSC)|Yaanb|yacy|Yahoo Ad monitoring|Yahoo Link Preview|YahooCacheSystem|YahooYSMcm|YandeG|yanga|yeti|Yo-yo|Yoleo Consumer|yoogliFetchAgent|YottaaMonitor|yourls\.org|Zao|Zemanta Aggregator|Zend\\\\Http\\\\Client|Zend_Http_Client|zgrab|ZnajdzFoto|ZyBorg#i', $user_agent, $badbot);
        if (isset($tartarus_Main_Settings['redirect_badbot_names']) && $tartarus_Main_Settings['redirect_badbot_names'] !== '') {
            $names = $tartarus_Main_Settings['redirect_badbot_names'];
            $names = str_replace(",", "|", $names);
            if (preg_match('#' . $names . '#i', $user_agent, $badbot2)) {
                $badbot = true;
            }
        }
        preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $user_agent, $matches);
        preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i', substr($user_agent, 0, 4), $matches2);
        preg_match('/ipad|android|android 3.0|xoom|sch-i800|playbook|tablet|kindle|NRD90M|SGP771|SHIELD|SM-T550|KFTHWI|LG-V410|nexus/i', $user_agent, $matches3);
        if (isset($tartarus_Main_Settings['log_visits']) && $tartarus_Main_Settings['log_visits'] !== 'None') {
            $exclude_own_traffic = 'off';
            if (isset($tartarus_Main_Settings['exclude_own_traffic'])) {
                $exclude_own_traffic = $tartarus_Main_Settings['exclude_own_traffic'];
            }
            if ($tartarus_Main_Settings['log_visits'] === 'All') {
                if (!$goodbot && !$badbot) {
                    if ($exclude_own_traffic == 'on') {
                        if (is_user_logged_in() && current_user_can('administrator')) {
                            return true;
                        }
                    }
                    if ($matches || $matches2) {
                        tartarus_log_visit($user_agent, 'Mobile');
                    } else {
                        if ($matches3) {
                            tartarus_log_visit($user_agent, 'Tablet');
                        } else {
                            tartarus_log_visit($user_agent, 'Desktop');
                        }
                    }
                } else {
                    if (preg_match('/slurp|yahoo|yahooseeker|yahoobot/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'YahooBot');
                    } elseif (preg_match('/googlebot|mediapartners|adsbot|feedfetcher-google/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'GoogleBot');
                    } elseif (preg_match('/msnbot|bingbot|bingpreview/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'BingBot');
                    } elseif (preg_match('/baidu/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'BaiduBot');
                    } elseif (preg_match('/yandex/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'YandexBot');
                    } elseif (preg_match('/facebookexternalhit|facebot/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'FacebookBot');
                    } elseif (preg_match('/ia_archiver/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'AlexaBot');
                    } elseif (preg_match('/twitterbot/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'TwitterBot');
                    } else {
                        tartarus_log_visit($user_agent, 'Bot');
                    }
                }
            } elseif ($tartarus_Main_Settings['log_visits'] === 'Human') {
                if ($exclude_own_traffic == 'on') {
                    if (is_user_logged_in() && current_user_can('administrator')) {
                        return true;
                    }
                }
                if ($matches || $matches2) {
                    tartarus_log_visit($user_agent, 'Mobile');
                } else {
                    if ($matches3) {
                        tartarus_log_visit($user_agent, 'Tablet');
                    } else {
                        tartarus_log_visit($user_agent, 'Desktop');
                    }
                }
            } elseif ($tartarus_Main_Settings['log_visits'] === 'Bot') {
                if ($goodbot || $badbot) {
                    if (preg_match('/slurp|Yahoo|yahooseeker|yahoobot/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'YahooBot');
                    } elseif (preg_match('/googlebot|mediapartners|adsbot|feedfetcher-google/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'GoogleBot');
                    } elseif (preg_match('/msnbot|bingbot|bingpreview/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'BingBot');
                    } elseif (preg_match('/baidu/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'BaiduBot');
                    } elseif (preg_match('/yandex/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'YandexBot');
                    } elseif (preg_match('/facebookexternalhit|facebot/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'FacebookBot');
                    } elseif (preg_match('/ia_archiver/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'AlexaBot');
                    } elseif (preg_match('/twitterbot/i', $user_agent, $matches9)) {
                        tartarus_log_visit($user_agent, 'TwitterBot');
                    } else {
                        tartarus_log_visit($user_agent, 'Bot');
                    }
                }
            }
        }
        if (isset($tartarus_Main_Settings['allow_logged_in']) && $tartarus_Main_Settings['allow_logged_in'] === 'on' && is_user_logged_in()) {
            return true;
        }
        if (isset($tartarus_Main_Settings['allow_admin']) && $tartarus_Main_Settings['allow_admin'] === 'on' && (is_admin() || tartarus_is_login())) {
            return true;
        }
        if (tartarus_check_whitelist()) {
            return true;
        }
        $referrer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
        if (isset($tartarus_Main_Settings['redirect_referralSpam']) && $tartarus_Main_Settings['redirect_referralSpam'] === 'on') {
            preg_match('#0n-line.tv|1-99seo.com|1-free-share-buttons.com|100dollars-seo.com|12masterov.com|1pamm.ru|1webmaster.ml|24x7-server-support.site|2your.site|3-letter-domains.net|4webmasters.org|5forex.ru|6hopping.com|7makemoneyonline.com|7zap.com|abc.xyz|abcdefh.xyz|abcdeg.xyz|acads.net|acunetix-referrer.com|adcash.com|adf.ly|adspart.com|adtiger.tk|adventureparkcostarica.com|adviceforum.info|advokateg.xyz|affordablewebsitesandmobileapps.com|afora.ru|akuhni.by|alfabot.xyz|alibestsale.com|allknow.info|allnews.md|allwomen.info|alpharma.net|altermix.ua|amt-k.ru|anal-acrobats.hol.es|anapa-inns.ru|android-style.com|anticrawler.org|arendakvartir.kz|arendovalka.xyz|arkkivoltti.net|artparquet.ru|aruplighting.com|autovideobroadcast.com|aviva-limoux.com|azartclub.org|azlex.uz|baixar-musicas-gratis.com|baladur.ru|balitouroffice.com|bard-real.com.ua|best-seo-offer.com|best-seo-software.xyz|best-seo-solution.com|bestmobilityscooterstoday.com|bestwebsitesawards.com|bif-ru.info|biglistofwebsites.com|billiard-classic.com.ua|biteg.xyz|bizru.info|black-friday.ga|blackhatworth.com|blogtotal.de|blue-square.biz|bluerobot.info|boltalko.xyz|boostmyppc.com|brakehawk.com|brateg.xyz|break-the-chains.com|brk-rti.ru|brothers-smaller.ru|budmavtomatika.com.ua|buketeg.xyz|bukleteg.xyz|burger-imperia.com|burn-fat.ga|buttons-for-website.com|buttons-for-your-website.com|buy-cheap-online.info|buy-cheap-pills-order-online.com|buy-forum.ru|call-of-duty.info|cardiosport.com.ua|cartechnic.ru|cenokos.ru|cenoval.ru|cezartabac.ro|chcu.net|chinese-amezon.com|ci.ua|cityadspix.com|civilwartheater.com|clicksor.com|coderstate.com|codysbbq.com|compliance-alex.xyz|compliance-alexa.xyz|compliance-andrew.xyz|compliance-brian.xyz|compliance-don.xyz|compliance-donald.xyz|compliance-elena.xyz|compliance-fred.xyz|compliance-george.xyz|compliance-irvin.xyz|compliance-ivan.xyz|compliance-john.top|compliance-julianna.top|conciergegroup.org|connectikastudio.com|cookie-law-enforcement-aa.xyz|cookie-law-enforcement-bb.xyz|cookie-law-enforcement-cc.xyz|cookie-law-enforcement-dd.xyz|cookie-law-enforcement-ee.xyz|cookie-law-enforcement-ff.xyz|cookie-law-enforcement-gg.xyz|cookie-law-enforcement-hh.xyz|cookie-law-enforcement-ii.xyz|cookie-law-enforcement-jj.xyz|cookie-law-enforcement-kk.xyz|cookie-law-enforcement-ll.xyz|cookie-law-enforcement-mm.xyz|cookie-law-enforcement-nn.xyz|cookie-law-enforcement-oo.xyz|cookie-law-enforcement-pp.xyz|cookie-law-enforcement-qq.xyz|cookie-law-enforcement-rr.xyz|cookie-law-enforcement-ss.xyz|cookie-law-enforcement-tt.xyz|cookie-law-enforcement-uu.xyz|cookie-law-enforcement-vv.xyz|cookie-law-enforcement-ww.xyz|cookie-law-enforcement-xx.xyz|cookie-law-enforcement-yy.xyz|cookie-law-enforcement-zz.xyz|copyrightclaims.org|covadhosting.biz|cubook.supernew.org|customsua.com.ua|cyber-monday.ga|dailyrank.net|darodar.com|dbutton.net|delfin-aqua.com.ua|demenageur.com|descargar-musica-gratis.net|detskie-konstruktory.ru|dipstar.org|djekxa.ru|djonwatch.ru|dktr.ru|dogsrun.net|dojki-hd.com|domain-tracker.com|dominateforex.ml|domination.ml|doska-vsem.ru|dostavka-v-krym.com|drupa.com|dvr.biz.ua|e-buyeasy.com|e-kwiaciarz.pl|easycommerce.cf|ecomp3.ru|econom.co|edakgfvwql.ru|egovaleo.it|ekatalog.xyz|ekto.ee|elmifarhangi.com|erot.co|escort-russian.com|este-line.com.ua|eu-cookie-law-enforcement2.xyz|euromasterclass.ru|europages.com.ru|eurosamodelki.ru|event-tracking.com|eyes-on-you.ga|fast-wordpress-start.com|fbdownloader.com|fix-website-errors.com|floating-share-buttons.com|for-your.website|forex-procto.ru|forsex.info|forum69.info|free-floating-buttons.com|free-share-buttons.com|free-social-buttons.com|free-social-buttons.xyz|free-social-buttons7.xyz|free-traffic.xyz|free-video-tool.com|freenode.info|freewhatsappload.com|fsalas.com|generalporn.org|germes-trans.com|get-free-social-traffic.com|get-free-traffic-now.com|get-your-social-buttons.info|getlamborghini.ga|getrichquick.ml|getrichquickly.info|ghazel.ru|ghostvisitor.com|girlporn.ru|gkvector.ru|glavprofit.ru|gobongo.info|goodprotein.ru|googlemare.com|googlsucks.com|guardlink.org|handicapvantoday.com|havepussy.com|hdmoviecamera.net|hdmoviecams.com|hongfanji.com|hosting-tracker.com|howopen.ru|howtostopreferralspam.eu|hulfingtonpost.com|humanorightswatch.org|hundejo.com|hvd-store.com|ico.re|igadgetsworld.com|igru-xbox.net|ilikevitaly.com|iloveitaly.ro|iloveitaly.ru|ilovevitaly.co|ilovevitaly.com|ilovevitaly.info|ilovevitaly.org|ilovevitaly.ru|ilovevitaly.xyz|iminent.com|imperiafilm.ru|increasewwwtraffic.info|investpamm.ru|iskalko.ru|ispaniya-costa-blanca.ru|it-max.com.ua|jjbabskoe.ru|justprofit.xyz|kabbalah-red-bracelets.com|kambasoft.com|kazrent.com|keywords-monitoring-success.com|keywords-monitoring-your-success.com|kino-fun.ru|kino-key.info|kinopolet.net|knigonosha.net|konkursov.net|law-check-two.xyz|law-enforcement-ee.xyz|law-enforcement-bot-ff.xyz|law-enforcement-check-three.xyz|law-six.xyz|laxdrills.com|legalrc.biz|littleberry.ru|livefixer.com|lsex.xyz|lumb.co|luxup.ru|magicdiet.gq|makemoneyonline.com|makeprogress.ga|manualterap.roleforum.ru|maridan.com.ua|marketland.ml|masterseek.com|mebelcomplekt.ru|mebeldekor.com.ua|med-zdorovie.com.ua|meds-online24.com|minegam.com|mirobuvi.com.ua|mirtorrent.net|mobilemedia.md|monetizationking.net|moneytop.ru|mosrif.ru|moyakuhnia.ru|muscle-factory.com.ua|myftpupload.com|myplaycity.com|net-profits.xyz|niki-mlt.ru|novosti-hi-tech.ru|nufaq.com|o-o-11-o-o.com|o-o-6-o-o.com|o-o-6-o-o.ru|o-o-8-o-o.com|o-o-8-o-o.ru|online-hit.info|online-templatestore.com|onlinetvseries.me|onlywoman.org|ooo-olni.ru|ownshop.cf|ozas.net|palvira.com.ua|petrovka-online.com|photokitchendesign.com|pizza-imperia.com|pizza-tycoon.com|popads.net|pops.foundation|pornhub-forum.ga|pornhub-forum.uni.me|pornhub-ru.com|pornoforadult.com|pornogig.com|pornoklad.ru|portnoff.od.ua|pozdravleniya-c.ru|priceg.com|pricheski-video.com|prlog.ru|producm.ru|prodvigator.ua|prointer.net.ua|promoforum.ru|pron.pro|psa48.ru|qualitymarketzone.com|quit-smoking.ga|qwesa.ru|rank-checker.online|rankings-analytics.com|ranksonic.info|ranksonic.net|ranksonic.org|rapidgator-porn.ga|rcb101.ru|rednise.com|replica-watch.ru|research.ifmo.ru|resellerclub.com|responsive-test.net|reversing.cc|rightenergysolutions.com.au|rospromtest.ru|rumamba.com|rusexy.xyz|sad-torg.com.ua|sady-urala.ru|sanjosestartups.com|santasgift.ml|savetubevideo.com|savetubevideo.info|screentoolkit.com|scripted.com|search-error.com|semalt.com|semaltmedia.com|seo-2-0.com|seo-platform.com|seo-smm.kz|seoanalyses.com|seoexperimenty.ru|seopub.net|sexsaoy.com|sexyali.com|sexyteens.hol.es|share-buttons.xyz|sharebutton.net|sharebutton.to|shop.xz618.com|sibecoprom.ru|simple-share-buttons.com|site-auditor.online|site5.com|siteripz.net|sitevaluation.org|sledstvie-veli.net|slftsdybbg.ru|slkrm.ru|slow-website.xyz|smailik.org|smartphonediscount.info|snip.to|snip.tw|soaksoak.ru|social-button.xyz|social-buttons-ii.xyz|social-buttons.com|social-traffic-1.xyz|social-traffic-2.xyz|social-traffic-3.xyz|social-traffic-4.xyz|social-traffic-5.xyz|social-traffic-7.xyz|social-widget.xyz|socialbuttons.xyz|socialseet.ru|socialtrade.biz|sohoindia.net|solitaire-game.ru|solnplast.ru|sosdepotdebilan.com|speedup-my.site|spin2016.cf|spravka130.ru|steame.ru|success-seo.com|superiends.org|supervesti.ru|taihouse.ru|tattooha.com|tedxrj.com|theguardlan.com|tomck.com|top1-seo-service.com|topquality.cf|topseoservices.co|traffic-cash.xyz|traffic2cash.org|traffic2cash.xyz|traffic2money.com|trafficgenius.xyz|trafficmonetize.org|trafficmonetizer.org|trion.od.ua|uasb.ru|unpredictable.ga|uptime.com|uptimechecker.com|uzungil.com|varikozdok.ru|vesnatehno.com|video--production.com|video-woman.com|videos-for-your-business.com|viel.su|viktoria-center.ru|vodaodessa.com|vodkoved.ru|w3javascript.com|wallpaperdesk.info|web-revenue.xyz|webmaster-traffic.com|webmonetizer.net|website-analyzer.info|website-speed-check.site|website-speed-checker.site|websites-reviews.com|websocial.me|wmasterlead.com|woman-orgasm.ru|wordpress-crew.net|wordpresscore.com|works.if.ua|ykecwqlixx.ru|youporn-forum.ga|youporn-forum.uni.me|youporn-ru.com|yourserverisdown.com|zastroyka.org|zoominfo.com|zvetki.ru#i', $referrer, $referrerSpam);
            if (isset($tartarus_Main_Settings['redirect_referralSpam_url']) && $tartarus_Main_Settings['redirect_referralSpam_url'] !== '') {
                $urls = $tartarus_Main_Settings['redirect_referralSpam_url'];
                $urls = str_replace(",", "|", $urls);
                if (preg_match('#' . $urls . '#i', $referrer, $referrerSpam2)) {
                    $referrerSpam = true;
                }
            }
            if ($referrerSpam) {
                if (!tartarus_recognize_spider()) {
                    tartarus_ban('ReferralSpam');
                }
                tartarus_show_banned();
            }
        }
        //redirect badbot
        if (isset($tartarus_Main_Settings['redirect_badbot']) && $tartarus_Main_Settings['redirect_badbot'] === 'on') {
            if ($badbot) {
                if (!tartarus_recognize_spider()) {
                    tartarus_ban('BadBotBan');
                }
                tartarus_show_banned();
            }
        }
        if (isset($tartarus_Main_Settings['redirect_goodbot']) && $tartarus_Main_Settings['redirect_goodbot'] === 'on') {
            if ($goodbot) {
                if (!tartarus_recognize_spider()) {
                    tartarus_ban('GoodBotBan');
                }
                tartarus_show_banned();
            }
        }
        //redirect badbot end
        if (isset($_GET['tartarus'])) {
            if (!tartarus_recognize_spider()) {
                tartarus_ban('TrappedBot');
            }
            tartarus_show_banned();
        } else {
            if (tartarus_recognize_spider()) {
                tartarus_show_banned();
            }
        }
        return false;
    }
    return true;
}

function tartarus_get_bot_specs($reason = 'manual')
{
    
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $ip_address = $_SERVER['HTTP_CLIENT_IP'];
    } else {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip_address = $_SERVER['REMOTE_ADDR'];
        }
    }
    $request_uri  = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $query_string = isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';
    $user_agent   = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    $referrer     = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
    $protocol     = isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : '';
    $method       = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '';
    $date         = date('Y/m/d h:i:s a', current_time('timestamp'));
    $vars         = array(
        $ip_address,
        $request_uri,
        $query_string,
        $user_agent,
        $referrer,
        $protocol,
        $method,
        $date,
        $reason
    );
    return $vars;
}
function tartarus_log_visit($user_agent, $type)
{
    $file    = mb_ereg_replace("([^\w\s\d\-_~,;\[\]\(\).])", '', $user_agent);
    $file    = mb_ereg_replace("([\.]{2,})", '', $file);
    $dir     = plugin_dir_path(__FILE__);
    $ua_file = $dir . 'logs/' . $file;
    if (file_exists($ua_file)) {
        $cnt = file_get_contents($ua_file);
        $cnt = explode(",", $cnt)[0];
        $cnt++;
        file_put_contents($ua_file, $cnt . ',' . $type);
    } else {
        file_put_contents($ua_file, '1,' . $type);
    }
}
function tartarus_ban($reason = 'TrappedBot')
{
    $tartarus_crawl_list   = get_option('tartarus_crawl_list');
    $vars                  = tartarus_get_bot_specs($reason);
    $tartarus_crawl_list[] = $vars;
    update_option('tartarus_crawl_list', $tartarus_crawl_list);
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['send_email']) && $tartarus_Main_Settings['send_email'] === 'on') {
        if (isset($tartarus_Main_Settings['send_email_address']) && $tartarus_Main_Settings['send_email_address'] != '') {
            $to      = $tartarus_Main_Settings['send_email_address'];
            $subject = '[Tartarus] A new web crawler just got banned!';
            $message = 'Specs: ' . PHP_EOL . implode(" ", $vars);
            $headers = 'From: tartarus@kisded.rf.gd' . "\r\n" . 'Reply-To: noreply@kisded.rf.gd' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . 'Content-Type: text/plain; charset=' . get_option('blog_charset', 'UTF-8') . PHP_EOL;
            wp_mail($to, $subject, $message, $headers);
        }
    }
}
function tartarus_show_banned()
{
    
    header("HTTP/1.1 403 Forbidden");
    header("Status: 403 Forbidden");
    header("Connection: close");
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['banned_text']) && $tartarus_Main_Settings['banned_text'] != '') {
        exit($tartarus_Main_Settings['banned_text']);
    } else {
        exit("You are not allowed to view this resource.");
    }
}
function tartarus_set_up_trap()
{
    $href                   = site_url('/?tartarus');
    $title                  = 'You are shown the Gates of Tartarus';
    $text                   = "Warning! This link is a trap for bad bots! Do not follow this link or you're IP adress will be banned from the site!";
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    $link                   = '<a ';
    if (isset($tartarus_Main_Settings['add_nofollow']) && $tartarus_Main_Settings['add_nofollow'] === 'on') {
        $link .= 'rel="nofollow" ';
    }
    $link .= 'style="display:none;" href="' . $href . '" title="' . $title . '">' . $text . '</a>' . PHP_EOL;
    echo $link;
}
add_action('admin_enqueue_scripts', 'tartarus_admin_load_files');
function tartarus_admin_load_files()
{
    wp_register_style('tartarus-browser-style', plugins_url('styles/tartarus-browser.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('tartarus-browser-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('tartarus-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('tartarus-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('tartarus-settings-app', plugins_url('res/tartarus-angular.js', __FILE__), array(), '1.0.0', true);
}
add_action('wp_head', 'tartarus_add_meta');
function tartarus_add_meta()
{
    $tartarus_Meta_Settings = get_option('tartarus_Meta_Settings', false);
    if (isset($tartarus_Meta_Settings['seo_noindex_posts'])) {
        $seo_noindex_posts = $tartarus_Meta_Settings['seo_noindex_posts'];
    } else {
        $seo_noindex_posts = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_pages'])) {
        $seo_noindex_pages = $tartarus_Meta_Settings['seo_noindex_pages'];
    } else {
        $seo_noindex_pages = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_media'])) {
        $seo_noindex_media = $tartarus_Meta_Settings['seo_noindex_media'];
    } else {
        $seo_noindex_media = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_category'])) {
        $seo_noindex_category = $tartarus_Meta_Settings['seo_noindex_category'];
    } else {
        $seo_noindex_category = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_archive'])) {
        $seo_noindex_archive = $tartarus_Meta_Settings['seo_noindex_archive'];
    } else {
        $seo_noindex_archive = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_search'])) {
        $seo_noindex_search = $tartarus_Meta_Settings['seo_noindex_search'];
    } else {
        $seo_noindex_search = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_tax'])) {
        $seo_noindex_tax = $tartarus_Meta_Settings['seo_noindex_tax'];
    } else {
        $seo_noindex_tax = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_nf'])) {
        $seo_noindex_nf = $tartarus_Meta_Settings['seo_noindex_nf'];
    } else {
        $seo_noindex_nf = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_home'])) {
        $seo_noindex_home = $tartarus_Meta_Settings['seo_noindex_home'];
    } else {
        $seo_noindex_home = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noindex_tag'])) {
        $seo_noindex_tag = $tartarus_Meta_Settings['seo_noindex_tag'];
    } else {
        $seo_noindex_tag = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_category'])) {
        $seo_nofollow_category = $tartarus_Meta_Settings['seo_nofollow_category'];
    } else {
        $seo_nofollow_category = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_archive'])) {
        $seo_nofollow_archive = $tartarus_Meta_Settings['seo_nofollow_archive'];
    } else {
        $seo_nofollow_archive = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_search'])) {
        $seo_nofollow_search = $tartarus_Meta_Settings['seo_nofollow_search'];
    } else {
        $seo_nofollow_search = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_tax'])) {
        $seo_nofollow_tax = $tartarus_Meta_Settings['seo_nofollow_tax'];
    } else {
        $seo_nofollow_tax = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_nf'])) {
        $seo_nofollow_nf = $tartarus_Meta_Settings['seo_nofollow_nf'];
    } else {
        $seo_nofollow_nf = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_home'])) {
        $seo_nofollow_home = $tartarus_Meta_Settings['seo_nofollow_home'];
    } else {
        $seo_nofollow_home = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_tag'])) {
        $seo_nofollow_tag = $tartarus_Meta_Settings['seo_nofollow_tag'];
    } else {
        $seo_nofollow_tag = '';
    }
    
    if (isset($tartarus_Meta_Settings['seo_noodp_category'])) {
        $seo_noodp_category = $tartarus_Meta_Settings['seo_noodp_category'];
    } else {
        $seo_noodp_category = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_archive'])) {
        $seo_noodp_archive = $tartarus_Meta_Settings['seo_noodp_archive'];
    } else {
        $seo_noodp_archive = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_search'])) {
        $seo_noodp_search = $tartarus_Meta_Settings['seo_noodp_search'];
    } else {
        $seo_noodp_search = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_tax'])) {
        $seo_noodp_tax = $tartarus_Meta_Settings['seo_noodp_tax'];
    } else {
        $seo_noodp_tax = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_nf'])) {
        $seo_noodp_nf = $tartarus_Meta_Settings['seo_noodp_nf'];
    } else {
        $seo_noodp_nf = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_home'])) {
        $seo_noodp_home = $tartarus_Meta_Settings['seo_noodp_home'];
    } else {
        $seo_noodp_home = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_tag'])) {
        $seo_noodp_tag = $tartarus_Meta_Settings['seo_noodp_tag'];
    } else {
        $seo_noodp_tag = '';
    }
    
    if (isset($tartarus_Meta_Settings['seo_noydir_category'])) {
        $seo_noydir_category = $tartarus_Meta_Settings['seo_noydir_category'];
    } else {
        $seo_noydir_category = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_archive'])) {
        $seo_noydir_archive = $tartarus_Meta_Settings['seo_noydir_archive'];
    } else {
        $seo_noydir_archive = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_search'])) {
        $seo_noydir_search = $tartarus_Meta_Settings['seo_noydir_search'];
    } else {
        $seo_noydir_search = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_tax'])) {
        $seo_noydir_tax = $tartarus_Meta_Settings['seo_noydir_tax'];
    } else {
        $seo_noydir_tax = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_nf'])) {
        $seo_noydir_nf = $tartarus_Meta_Settings['seo_noydir_nf'];
    } else {
        $seo_noydir_nf = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_home'])) {
        $seo_noydir_home = $tartarus_Meta_Settings['seo_noydir_home'];
    } else {
        $seo_noydir_home = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_tag'])) {
        $seo_noydir_tag = $tartarus_Meta_Settings['seo_noydir_tag'];
    } else {
        $seo_noydir_tag = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_posts'])) {
        $seo_nofollow_posts = $tartarus_Meta_Settings['seo_nofollow_posts'];
    } else {
        $seo_nofollow_posts = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_pages'])) {
        $seo_nofollow_pages = $tartarus_Meta_Settings['seo_nofollow_pages'];
    } else {
        $seo_nofollow_pages = '';
    }
    if (isset($tartarus_Meta_Settings['seo_nofollow_media'])) {
        $seo_nofollow_media = $tartarus_Meta_Settings['seo_nofollow_media'];
    } else {
        $seo_nofollow_media = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_posts'])) {
        $seo_noodp_posts = $tartarus_Meta_Settings['seo_noodp_posts'];
    } else {
        $seo_noodp_posts = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_pages'])) {
        $seo_noodp_pages = $tartarus_Meta_Settings['seo_noodp_pages'];
    } else {
        $seo_noodp_pages = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noodp_media'])) {
        $seo_noodp_media = $tartarus_Meta_Settings['seo_noodp_media'];
    } else {
        $seo_noodp_media = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_posts'])) {
        $seo_noydir_posts = $tartarus_Meta_Settings['seo_noydir_posts'];
    } else {
        $seo_noydir_posts = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_pages'])) {
        $seo_noydir_pages = $tartarus_Meta_Settings['seo_noydir_pages'];
    } else {
        $seo_noydir_pages = '';
    }
    if (isset($tartarus_Meta_Settings['seo_noydir_media'])) {
        $seo_noydir_media = $tartarus_Meta_Settings['seo_noydir_media'];
    } else {
        $seo_noydir_media = '';
    }
    if (isset($tartarus_Meta_Settings['seo_misc'])) {
        $seo_misc = $tartarus_Meta_Settings['seo_misc'];
    } else {
        $seo_misc = '';
    }
    $tartarus_Main_Settings = get_option('tartarus_Main_Settings', false);
    if (isset($tartarus_Main_Settings['tartarus_enabled'])) {
        $tartarus_enabled = $tartarus_Main_Settings['tartarus_enabled'];
    } else {
        $tartarus_enabled = '';
    }
    if ($tartarus_enabled == 'on' && $seo_misc == 'on') {
        echo PHP_EOL;
        if (tartarus_get_page_type() == "single") {
            $robots = "";
            if ($seo_noindex_posts == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_posts == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_posts == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_posts == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_posts == "on") || ($seo_noodp_posts == "on") || ($seo_nofollow_posts == "on") || ($seo_noindex_posts == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (tartarus_get_page_type() == "page") {
            $robots = "";
            if ($seo_noindex_pages == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_pages == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_pages == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_pages == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_pages == "on") || ($seo_noodp_pages == "on") || ($seo_nofollow_pages == "on") || ($seo_noindex_pages == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (tartarus_get_page_type() == "attachment") {
            $robots = "";
            if ($seo_noindex_media == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_media == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_media == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_media == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_media == "on") || ($seo_noodp_media == "on") || ($seo_nofollow_media == "on") || ($seo_noindex_media == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (tartarus_get_page_type() == "category") {
            $robots = "";
            if ($seo_noindex_category == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_category == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_category == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_category == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_category == "on") || ($seo_noodp_category == "on") || ($seo_nofollow_category == "on") || ($seo_noindex_category == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (tartarus_get_page_type() == "archive") {
            $robots = "";
            if ($seo_noindex_archive == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_archive == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_archive == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_archive == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_archive == "on") || ($seo_noodp_archive == "on") || ($seo_nofollow_archive == "on") || ($seo_noindex_archive == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (tartarus_get_page_type() == "search") {
            $robots = "";
            if ($seo_noindex_search == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_search == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_search == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_search == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_search == "on") || ($seo_noodp_search == "on") || ($seo_nofollow_search == "on") || ($seo_noindex_search == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (tartarus_get_page_type() == "tax") {
            $robots = "";
            if ($seo_noindex_tax == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_tax == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_tax == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_tax == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_tax == "on") || ($seo_noodp_tax == "on") || ($seo_nofollow_tax == "on") || ($seo_noindex_tax == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (tartarus_get_page_type() == "notfound") {
            $robots = "";
            if ($seo_noindex_nf == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_nf == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_nf == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_nf == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_nf == "on") || ($seo_noodp_nf == "on") || ($seo_nofollow_nf == "on") || ($seo_noindex_nf == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if ((tartarus_get_page_type() == "tag") || (tartarus_get_page_type() == "front")) {
            $robots = "";
            if ($seo_noindex_home == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_home == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_home == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_home == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_home == "on") || ($seo_noodp_home == "on") || ($seo_nofollow_home == "on") || ($seo_noindex_home == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
        if (tartarus_get_page_type() == "home") {
            $robots = "";
            if ($seo_noindex_tag == "on")
                $robots .= "noindex, ";
            if ($seo_nofollow_tag == "on")
                $robots .= "nofollow, ";
            if ($seo_noodp_tag == "on")
                $robots .= "noodp, ";
            if ($seo_noydir_tag == "on")
                $robots .= "noydir, ";
            if (($seo_noydir_tag == "on") || ($seo_noodp_tag == "on") || ($seo_nofollow_tag == "on") || ($seo_noindex_tag == "on"))
                $robots = trim($robots, ", ");
            if ($robots != "") {
?>
        <meta content='<?php
                echo $robots;
?>' name='robots'/>
        <?php
            }
        }
    }
}
function tartarus_get_page_type()
{
    global $wp_query;
    $loop = 'notfound';
    if ($wp_query->is_page) {
        $loop = is_front_page() ? 'front' : 'page';
    } elseif ($wp_query->is_home) {
        $loop = 'home';
    } elseif ($wp_query->is_single) {
        $loop = ($wp_query->is_attachment) ? 'attachment' : 'single';
    } elseif ($wp_query->is_category) {
        $loop = 'category';
    } elseif ($wp_query->is_tag) {
        $loop = 'tag';
    } elseif ($wp_query->is_tax) {
        $loop = 'tax';
    } elseif ($wp_query->is_archive) {
        if ($wp_query->is_day) {
            $loop = 'archive';
        } elseif ($wp_query->is_month) {
            $loop = 'archive';
        } elseif ($wp_query->is_year) {
            $loop = 'archive';
        } elseif ($wp_query->is_author) {
            $loop = 'archive';
        } else {
            $loop = 'archive';
        }
    } elseif ($wp_query->is_search) {
        $loop = 'search';
    } elseif ($wp_query->is_404) {
        $loop = 'notfound';
    }
    return $loop;
}
require(dirname(__FILE__) . "/res/tartarus-main.php");
require(dirname(__FILE__) . "/res/tartarus-blocked-list.php");
require(dirname(__FILE__) . "/res/tartarus-page-access.php");
require(dirname(__FILE__) . "/res/tartarus-file-editor.php");
require(dirname(__FILE__) . "/res/tartarus-htaccess-editor.php");
require(dirname(__FILE__) . "/res/tartarus-recaptcha-integrition.php");
require(dirname(__FILE__) . "/res/tartarus-meta.php");
?>